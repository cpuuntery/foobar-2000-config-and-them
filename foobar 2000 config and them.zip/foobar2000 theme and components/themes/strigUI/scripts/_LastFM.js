// http://ws.audioscrobbler.com/2.0/?method=track.getInfo&api_key=179b25d95e633097ec682c58b4a993ec&artist=30%20Seconds%20To%20Mars&track=Walk%20On%20Water&format=json&autocorrect=1&user=TheStrigoy

// === LOAD STUFF
include(fb.FoobarPath + 'themes\\strigUI\\scripts\\Flags.js');
include(fb.FoobarPath + 'themes\\strigUI\\scripts\\md5.js');

// === HELPERS {{
// Generate/modify colours
function RGBA(r, g, b, a) {
	return a << 24 | r << 16 | g << 8 | b;
}
function RGB(r, g, b) {
	return 0xFF000000 | r << 16 | g << 8 | b;
}
// Helper function for DrawString() and MeasureString()
// args: h_align, v_align, trimming, flags
function StringFormat() {
	var h_align = 0, v_align = 0, trimming = 0, flags = 0;
	switch (arguments.length)
	{
	// fall-thru
	case 4:
		flags = arguments[3];
	case 3:
		trimming = arguments[2];
	case 2:
		v_align = arguments[1];
	case 1:
		h_align = arguments[0];
		break;
	default:
		return 0;
	}
	return ((h_align << 28) | (v_align << 24) | (trimming << 20) | flags);
}
var FontStyle = {
        Regular: 0,
        Bold: 1,
        Italic: 2,
        BoldItalic: 3,
        Underline: 4,
        Strikeout: 8
};
// text alignment
// ex var LineStrFmt = StringFormat(StringAlignment.Near,StringAlignment.Near,StringTrimming.None,StringFormatFlags.LineLimit);
var StringAlignment = {
        Near: 0,
        Center: 1,
        Far: 2
};
var StringTrimming = {
        None: 0,
        Character: 1,
        Word: 2,
        EllipsisCharacter: 3,
        EllipsisWord: 4,
        EllipsisPath: 5
};
// === HELPERS}}

// === VARS {{
var	WaitTimer, WaitTimerID, FOCUSFLAG, key, XYinLove, XYref, MetaDB, love_timer,
	api_sig, api_sig2, data, regdate_error, lfm, error, 
	MaxRange, h_link, d_link, MetaPath, m_hover, g_hover ;

var	lastfm_status = 0,
	error_count = 0,
	wait = 1,
	loveIMG_state = 0,
	Userloved = 0,
	GotInfo = 0,
	ww = 0,
	wh = 0,
	Y_OFFSET = 0,
	sum_height = 0,
	spcounter = 0,
	charcounter = 0,
	linecounter = 1,
	longeststr = "";
	
var	lm = 5, rm = 5, tm = 5, bm = 0; // panel margins

var	hofset = 170, // LOVE BUTTON dimensions 
	vofset = 52,
	imgw = 22;

var api_key = read_option("api_key"); //opt_api_key
var secret = read_option("secret");
var username = read_option("username"); //opt_username
//var password = read_option("password");
var ini_sessionkey = read_option("skey"); //utils.ReadINI(fb.ProfilePath + '_cfg.ini', 'LFMopts', 'skey');
if ( ini_sessionkey ) key = ini_sessionkey;
var useragent = "foobar2000_LFMscript";

var enpass = read_option("password");//Base64.encode(aes_str);
var password = Base64.decode(enpass);

var normal_color = RGB(80, 80, 80);
var hover_color = RGB(80, 80, 80); // RGB(0, 120, 255);

var tooltip = window.CreateTooltip();
tooltip.SetMaxWidth( 200 );
var EnableTooltip = true;

var status_images = [ '', 'hourglass.png', 'red_cross.png' ]; // loveIMG_state defined: 0 - OK, 1 - WAITING, 2 - FAILED
var imgPath = fb.ProfilePath + "themes\\strigUI\\images\\LastFM\\";
try { //img vars
	var img_lastfm_logo_red = gdi.Image(imgPath + "lfm_logo_shadow.png");
	var img_lastfm_flip = gdi.Image(imgPath + "scrobbleflip.png");
    var heart_red = gdi.Image(imgPath + "heart.png");
    var heart_grey = gdi.Image(imgPath + "heart_grey.png");
    var heart_add = gdi.Image(imgPath + "heart_add.png");
    var heart_delete = gdi.Image(imgPath + "heart_delete.png");
    var key_image = gdi.Image(imgPath + "bullet_key.png");
    var key_big_image = gdi.Image(imgPath + "key.png");
    var disconnect_image = gdi.Image(imgPath + "disconnect.png");
    var info_image = gdi.Image(imgPath + "information.png");
}
catch(e) { }

// default fonts
if ( utils.CheckFont( "Segoe UI" ) ) {
	var font_label = gdi.Font("Segoe UI", 12, FontStyle.Bold);
	var font_num = gdi.Font("Segoe UI", 11, FontStyle.Bold);
	var font_normal = gdi.Font("Segoe UI", 12, FontStyle.Regular);
	var font_header = gdi.Font("Segoe UI", 15, FontStyle.Bold);
} else {
	var font_label = gdi.Font("Tahoma", 11, FontStyle.Bold);
	var font_num = gdi.Font("Arial", 11, FontStyle.Bold);
	var font_normal = gdi.Font("Tahoma", 12, FontStyle.Regular);
	var font_header = gdi.Font("Tahoma", 15, FontStyle.Bold);
}

var LineStrFmt = StringFormat(StringAlignment.Near,StringAlignment.Near,StringTrimming.None,StringFormatFlags.LineLimit); // string format
var wsShell = new ActiveXObject("WScript.Shell");
//var XMLDOM=new ActiveXObject("Microsoft.XMLDOM");
var metadb = OutputMetadb();
var np = [fb.TitleFormat("%artist%").Eval(true), fb.TitleFormat("%album%").Eval(true), fb.TitleFormat("%title%").Eval(true)];
//np = [fb.TitleFormat("%artist%").EvalWithMetadb(MetaDB), fb.TitleFormat("%album%").EvalWithMetadb(MetaDB), fb.TitleFormat("%title%").EvalWithMetadb(MetaDB)]
//np = [Eval(metadb, "%artist%"), Eval(metadb, "%album%"), Eval(metadb, "%title%")];


// Arrays
var lastfm_data = [];
var lastfm_xmlhttp = [];
var lastfm_xmlDoc = [];
var text_Hs = [];
var text_Ws = [];
var CorrectedData = []; //artist - album - track

var TLs = new Array(12);
for (let i = 0; i <= 12; i++) {
	TLs[i] = new TextLink(0, 0, 0, 0, function () {}, "", "");
}
// TLheart = new TextLink(0, 0, 25, 25, function () {}, "�", "Loved Track")
// === VARS }}

// === CALLBACK FUNCTIONS {{
// Mode
var CurrentMode = parseInt( utils.ReadINI(fb.ProfilePath + '_cfg.ini', 'LFMopts', 'fav_track_mode', 2) );
/*
function Eval( meta, field ) {
    path = meta ? meta.Path : '';
    return (path.indexOf("://") > 0) ?  fb.TitleFormat( field ).Eval( true ) : fb.TitleFormat( field ).EvalWithMetadb( meta );
}
*/

// Metadb
function OutputMetadb() {
    switch ( CurrentMode ) {
	case 3 :
		return ( fb.GetFocusItem(true) ? fb.GetFocusItem(true) : false );
		break;
	default:
		return ( fb.IsPlaying ? fb.GetNowPlaying() : ( fb.GetFocusItem(true) ? fb.GetFocusItem(true) : false ));
    }
}
function RateTrack(value) {
	metadb = OutputMetadb();
	let bool = new FbMetadbHandleList(metadb);
	let obj = {"RATING" : value};
	bool.UpdateFileInfoFromJSON(JSON.stringify(obj));
	//console.log('[f] RATING TRACK -> '+value)
}

//var aes_encr = CryptoJS.AES.encrypt(aes_str, aes_key);
//var aes_decrtext = CryptoJS.AES.decrypt(aes_encr, aes_key);
//console.log ('[===================] \n encrypting password [' +password+'] => AES HASH [' + aes_encr +' \n DECRYPTING AES ^ => ' + aes_decrtext + '] \n [===================]');

// Options config {{
function update_option(optname, optvalue) {
		//var ini_ = utils.ReadINI(fb.ProfilePath + '_cfg.ini', 'LFMopts', optname);
		let ini_ = read_option(optname);
		if ( optname ) utils.WriteINI( fb.ProfilePath + '_cfg.ini', 'LFMopts', optname, optvalue);
		else if ( !optname && ini_ ) optname = ini_;
		//else if ( !optname && !ini_) optname = optvalue;
		else optname = optvalue;
}
 
function read_option(optname) {
		let ini_ = utils.ReadINI(fb.ProfilePath + '_cfg.ini', 'LFMopts', optname);
		return ini_
}

// API KEY DATA CHECK
function check_data() {
	try {
		if ( username.length > 3 && username != null && username != undefined ) var un = true;
		else return false;
		if ( api_key.length > 3 && api_key != null && api_key != undefined ) var ak = true;
		else return false;
		if ( ak && un )  return true;
    }
    catch(e) { }
}

// Cursor follow tools {{
function CursorFollow(FollowMode) {
	switch (FollowMode) {
		case 2:
			if (fb.IsPlaying) on_playback_new_track();
			else on_item_focus_change();
			break;
		case 3:
			on_item_focus_change();
			break;
	}
}

// Context menu {{
function show_context_menu(x, y) {
	var _menu = window.CreatePopupMenu();
	var _followMode = window.CreatePopupMenu();
	var ret;
	if (username.length > 0 && api_key.length == 32) {
		_menu.AppendMenuItem(username.length > 0 && api_key.length == 32 ? MF_STRING : MF_GRAYED, 1, "Update Last.fm Data");
		
		_followMode.AppendMenuItem(MF_STRING, 2, "Playing item");
		_followMode.AppendMenuItem(MF_STRING, 3, "Current selection");
		_followMode.CheckMenuRadioItem(2, 3, CurrentMode);
		_followMode.AppendTo(_menu, MF_STRING, "Focus settings");
		_menu.AppendMenuItem(MF_SEPARATOR, 0, 0);
	}
	if (username.length == 0) {
		_menu.AppendMenuItem(MF_STRING, 6, "ENTER your Last.fm USERNAME...");
	} else { _menu.AppendMenuItem(MF_STRING, 6, "Change Last.fm username"); }
	if (password.length == 0) {	
		_menu.AppendMenuItem(MF_STRING, 5, "ENTER your PASSWORD...");
	} else { _menu.AppendMenuItem(MF_STRING, 5, "Change password"); }
	_menu.AppendMenuItem(MF_SEPARATOR, 0, 0);
	if (!api_key || api_key.length != 32) {
		_menu.AppendMenuItem(MF_STRING, 7, "Set API key...");
	} else { _menu.AppendMenuItem(MF_STRING, 7, "Change API key..."); }
	if (!secret || secret.length != 32) {
		_menu.AppendMenuItem(MF_STRING, 4, "Set SECRET key...");
	} else { _menu.AppendMenuItem(MF_STRING, 4, "Change SECRET key..."); }
	
	ret = _menu.TrackPopupMenu(x, y);
	switch (ret) {
		case 1:
			//if ( loveIMG_state != 1 && !key ) Auth();
			lastfm_status = 0;
			wait = 1;
			window.Repaint();
			//CursorFollow(Properties.Panel.CursorFollowMode);
			CursorFollow(CurrentMode);
			break;
		case 2:
			//SetCursorFollowMode(2);
			//break;
			CurrentMode = ret;
			utils.WriteINI( fb.ProfilePath + '_cfg.ini', 'LFMopts', 'fav_track_mode', 2);
			break;
		case 3:
			//SetCursorFollowMode(3);
			//break;
			
			CurrentMode = ret;
			utils.WriteINI( fb.ProfilePath + '_cfg.ini', 'LFMopts', 'fav_track_mode', 3);
			break;
		case 4:
			//secret = InputBox("Please enter your Last.fm secret key", "Last.fm panel", secret);
			secret = utils.InputBox(window.ID, "Please enter your Last.fm password", "Last.fm panel", secret);
			if (!secret) secret = "";
			update_option("secret", secret);
			if (check_data()) window.Reload();
			break;

		case 5:
			//password = InputBox("Please enter your Last.fm password", "Last.fm panel", password);
			password = utils.InputBox(window.ID, "Please enter your Last.fm password", "Last.fm panel", password);
			if (!password) password = "";
				enpass = Base64.encode(password);
				//update_option("password", password);
				update_option("password", enpass);
				if (check_data() && password.length != 0) window.Reload();
			break;
		case 6:
			//username = InputBox("Please enter your Last.fm username", "Last.fm panel", username);
			username = utils.InputBox(window.ID, "Please enter your Last.fm username", "Last.fm panel", username);
			if (!username) username = "";
			update_option("username", username);
			if (check_data()) window.Reload();
			//CursorFollow(CurrentMode);
			break;
		case 7:
			//api_key = InputBox("Please enter your Last.fm API KEY (http://www.last.fm/api/account)", "Last.fm panel", api_key);
			api_key = utils.InputBox(window.ID, "Please enter your Last.fm API KEY (http://www.last.fm/api/account)", "Last.fm panel", api_key);
			if (!api_key) api_key = "";
			update_option("api_key", api_key);
			if (check_data()) window.Reload();
			//CursorFollow(CurrentMode);
			break;
	       /* case 8:
			window.ShowProperties();
			break;*/
	}
	//_menu.Dispose();
	//_followMode.Dispose();
	return true;
}
// Context menu }}

// Button class {{
function TextLink(x, y, width, height, fn_onclick, label, tiptext) {
	this.x = x;
	this.y = y;
	this.Width = width;
	this.Height = height;
	this.label = label;
	this.tiptext = tiptext;
	this.TestProp = "";
	this.NeedRefresh = 0;
	this.oldstate = 0; // 0=normal, 1=hover, 2=down.
	this.state = 0;
	this.opacity = 0; // Opacity of new state image.
	this.step = 0;
	this.show = true;
	this.NeedReset = false;
	this.OnClick = fn_onclick;
 
	this.ChangeState = function (s) {
		this.oldstate = this.state;
		this.state = s;
		this.opacity = 0;
		this.NeedRefresh = 1;
		switch (s) {
			case 0:
				this.step = 40; // Step of changing to normal state.
				tooltip.Deactivate();
				tooltip.Text = "";
				break;
			case 1:
				this.step = 75; // hover state.
				if (EnableTooltip) {
					tooltip.Text = this.tiptext;
					tooltip.Activate();
				}
				break;
			case 2:
				this.step = 85; // down state.
				tooltip.Deactivate();
				tooltip.Text = "";
				break;
		}
	}
 
	this.isXYok = function (x2, y2) {
		return (x2 >= this.x && y2 >= this.y + Y_OFFSET && x2 <= this.x + this.Width && y2 <= this.y + Y_OFFSET + this.Height) ? true : false;
	}
 
	this.Draw = function (x2, y2, gr) {
		x2 = this.x; //disabled
		y2 = this.y; //disabled
		if (this.opacity < 100) {
			switch (this.oldstate) {
				case 0:
					//gr.FillSolidRect(this.x, this.y + Y_OFFSET, this.Width, this.Height, RGBA(0, 120, 220, 100));
					gr.DrawString(this.label, font_normal, normal_color, this.x + 4, this.y + Y_OFFSET, this.Width - 4, this.Height, LineStrFmt);
					break;
				case 1:
					//gr.FillSolidRect(this.x, this.y + Y_OFFSET, this.Width, this.Height, RGBA(0, 130, 230, 100));
					gr.DrawString(this.label, font_normal, hover_color, this.x + 4, this.y + Y_OFFSET, this.Width - 4, this.Height, LineStrFmt);
					break;
				case 2:
					//gr.FillSolidRect(this.x, this.y + Y_OFFSET, this.Width, this.Height, RGBA(0, 136, 236, 100));
					gr.DrawString(this.label, font_normal, hover_color, this.x + 4, this.y + Y_OFFSET, this.Width - 4, this.Height, LineStrFmt);
					break;
				default:
					break;
			}
		}
 
		if (this.opacity) {
			switch (this.state) {
				case 0:
					//gr.FillSolidRect(this.x, this.y + Y_OFFSET, this.Width, this.Height, RGBA(0, 120, 220, this.opacity));
					gr.DrawString(this.label, font_normal, normal_color, this.x + 4, this.y + Y_OFFSET, this.Width, this.Height, LineStrFmt);
					break;
				case 1:
					//gr.FillSolidRect(this.x, this.y + Y_OFFSET, this.Width, this.Height, RGBA(0, 130, 230, this.opacity));
					gr.DrawString(this.label, font_normal, hover_color, this.x + 4, this.y + Y_OFFSET, this.Width, this.Height, LineStrFmt);
					break;
				case 2:
					//gr.FillSolidRect(this.x, this.y + Y_OFFSET, this.Width, this.Height, RGBA(0, 136, 236, this.opacity));
					gr.DrawString(this.label, font_normal, hover_color, this.x + 4, this.y + Y_OFFSET, this.Width, this.Height, LineStrFmt);
					break;
			}
		}
	}
}
// Button class }}

// Calculate the max range of buttons, for increasing refresh speed.
function GetCoordinates() { 
	MaxRange = {
			x: TLs[0].x,
			y: TLs[0].y + Y_OFFSET,
			Width: TLs[0].Width,
			Height: TLs[0].Height
		}
	for (var i = 1; i < TLs.length - 1; i++) {
		if (TLs[i].show) {
			MaxRange.x = Math.min(TLs[i].x, MaxRange.x);
			MaxRange.y = Math.min(TLs[i].y + Y_OFFSET, MaxRange.y);
			MaxRange.Width = Math.max(TLs[i].x + TLs[i].Width - MaxRange.x, MaxRange.Width);
			MaxRange.Height = Math.max(TLs[i].y + Y_OFFSET + TLs[i].Height - MaxRange.y, MaxRange.Height);
		}
	}
}

// === main timer constructor 
function _waitTimer() {
	this.Stop = function () {
		if (WaitTimerID) {
			window.ClearTimeout(WaitTimerID);
			WaitTimerID = null;
			//window.Repaint();
		}
	}
	this.Start = function () {
		WaitTimerID = window.SetTimeout(function () {
			WaitTimerID = null;
			lastfm_status = 0;
			wait = 1;
			MetaDB = fb.GetFocusItem();
			FOCUSFLAG = true;
			if (MetaDB){
				FOCUSFLAG = false;
				np = [fb.TitleFormat("%artist%").EvalWithMetadb(MetaDB), fb.TitleFormat("%album%").EvalWithMetadb(MetaDB), fb.TitleFormat("%title%").EvalWithMetadb(MetaDB)];
				if (np[0] == "?" && np[1] == "?" ) {
					wait = -2;
					window.Repaint();
					return;
				}
				lastfm_status = 0;
				wait = 1;
				window.Repaint();
				//lfm_startWork(); 
				lfm_get_artist(); // THE MADNESS BEGINS HERE
				//if (CorrectedData[1] != np[0]) {console.log ('\n[f] .STARTtimer => TITLE CHANGE REQUIRED \n [' + np[0] + '] => [' + CorrectedData[1] + ']\n');}				
			} else {
				wait = -2;
				window.Repaint();
			}
		}, 250);
	}
}

// === LASTFM FUNCTIONS {{ [welcome to the callback hell]
/*
function lfm_startWork() {
	console.log('................[1] start work');
    lfm_get_artist();
    //lfm_get_data();
}*/
function lfm_get_artist () {
	//console.log('................[2] GET ARTIST');
	let method = 'artist.getinfo';
	_LFM.get('artist.getinfo', 1, function (){
		//console.log('                [2] STORE corrected VALUE in .get CALLBACK np[0] = '+np[0] + ' CD => ' + CorrectedData[1]);
		lfm_get_data();

	});
}
function lfm_get_data () {
	//console.log('................[3] get the rest data');
	_LFM.get('user.getinfo', 0);
	_LFM.get('album.getinfo', 2);
	_LFM.get('track.getinfo', 3, function () {
		//console.log('                [3] STORE correct LOVE value ');
		lfm_define_love();
	});
}
function lfm_parse_data(id, callback) {
//for (let id = 0; id <=4; id++){
	if (lastfm_xmlhttp[id].status == 200) { //success
		//console.log('..[f] updating info with lfm_parse_data getinfo api call ' + id);
		lastfm_status++;
		lfm_define_artist();
		wait_lastfm_data();
		callback(); // => from _LFM.get
	}
	if (this.xmlhttp.status >= 400) { //error statuses
		error_count++;
		lastfm_status++;
	}
//}
}

function wait_lastfm_data(id, p) {
	if (lastfm_status == 4 && error_count < 4) {
		//console.log('[f] wait_lastfm_data update');
		lastfm_status = wait = 0;
		Y_OFFSET = 0;
		error_count = 0;
		process_lastfm_data();
		lastfm_update_love();
		return; 
	} else if (lastfm_status < 4) {
		wait = 1;
	} else if (error_count == 4) {
		wait = -1;
		error_count = 0;
		window.Repaint();
	}
}

function lfm_define_artist() { // trying to get correct artist name 
	try {lastfm_xmlDoc[1] = JSON.parse(lastfm_xmlhttp[1].responseText);} catch (e) {};
	try {CorrectedData[1] = lastfm_xmlDoc[1].artist.name; // write auto-corrected artist name in array
	} catch (e) {};
	//console.log ('[f] lfm_define_>>>>>>>>>>>>>>>>>>>>>>>>>             '+ CorrectedData[1]);
	return CorrectedData[1]
}

function lfm_define_love() { // getting LOVE value for the corrected [artist - track] pair 
	//if (lastfm_status == 4 && error_count < 4) {
	try {lastfm_xmlDoc[3] = JSON.parse(lastfm_xmlhttp[3].responseText);} catch (e) {};
	try {lastfm_data[3][3] = Userloved = lastfm_xmlDoc[3].track.userloved;
	} catch (e) {};
	//console.log ('  >[f] DEFINE LOVE >>>>>>>>>>>>>>>>>>>>>>>>>             '+ lastfm_data[3][3]);
	//window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area
	return lastfm_data[3][3]
}

function process_lastfm_data(callback) {
	//console.log ('[f]               > PROSESSSSSSSSSSSSSSSS DATAAAAAAAAAAAAAAAAAA <');
	this.getCounters = (data, id, pos) => {
		let strdata = "lastfm_xmlDoc["+id+"]."+ data;
		try{ 
			lastfm_data[id][pos] = eval(strdata).replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ')
		} catch (e) {
			lastfm_data[id][pos] = "0";
			//console.log ("[ERR] getting "+data+" info failed! Set value to 0.");
		}
		return lastfm_data[id][pos];
	}
	/*
	for (id = 0; id < 4; id++) {
		lastfm_xmlDoc[id] = JSON.parse(lastfm_xmlhttp[id].responseText);
		try {
			if (lastfm_xmlDoc[id].error) error = "last.fm API error: " + lastfm_xmlDoc[id].error + " : " + lastfm_xmlDoc[id].message;
		} catch (e) {
			error = null;
		}
	}*/
	for (id = 0; id < 4; id++) {
		try {lastfm_xmlDoc[id] = JSON.parse(lastfm_xmlhttp[id].responseText);} catch (e) {};
		//try {lastfm_xmlDoc[id] = JSON.parse(this.xmlhttp.responseText);} catch (e) {};
		
		switch (id) {
		case 0: // storing USER TOTAL playcount data in lastfm_data array
			try { // Userinfo and total playcount
				lastfm_data[id][0] = lastfm_xmlDoc[id].user.playcount;
				username = lastfm_xmlDoc[id].user.name;
			} catch (e) {lastfm_data[id][0] = "0";}
			try { // Registration date to count stats
				lastfm_data[id][4] = lastfm_xmlDoc[id].user.registered;
				regdate_error = false;
			} catch (e) {regdate_error = true; lastfm_data[id][4] = "";}
		 
			date = new Date().getTime() / 1;
			if (!regdate_error) {
				try {
					utc = Date.UTC(lastfm_data[id][4].substring(0, 4), (lastfm_data[id][4].substring(5, 7) - 1), lastfm_data[id][4].substring(8, 10), 0, 0, 0);
				} catch (e) {utc = 0;}
				try {
					lastfm_data[id][1] = "" + Math.round((lastfm_data[id][0] / ((date - utc) / 86400000)) * 100) / 100; // playcount per day
					lastfm_data[id][2] = "" + Math.round((lastfm_data[id][0] / ((date - utc) / 604800000)) * 10) / 10; // playcount per week
					lastfm_data[id][3] = "" + Math.round((lastfm_data[id][0] / ((date - utc) / 2629743000)) * 1) / 1; // playcount per month
					// format values
					lastfm_data[id][1] = lastfm_data[id][1].replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ');
					lastfm_data[id][2] = lastfm_data[id][2].replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ');
					lastfm_data[id][3] = lastfm_data[id][3].replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ');
					// replace value with formatted one after we done counting
					lastfm_data[id][0] = lastfm_data[id][0].replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 '); 
				} catch (e) {lastfm_data[id][1] = "0";lastfm_data[id][2] = "0";lastfm_data[id][3] = "0"; lastfm_data[id][0] = "0";}
			} else {
				lastfm_data[id][1] = "0";
				lastfm_data[id][2] = "0";
				lastfm_data[id][3] = "0";
			}
			break;
		case 1: // storing USER [ARTIST - ALBUM - TRACK] playcount data
			this.getCounters ( "artist.stats.userplaycount", 1, id);
			this.getCounters ( "album.userplaycount", 2, id);
			this.getCounters ( "track.userplaycount", 3, id);
			try {
				CorrectedData[id] = lastfm_xmlDoc[id].artist.name; // write auto-corrected artist name in array
				for (i = 0; i < 5; i++) {
					try {
						lastfm_data[id][3][i] = lastfm_xmlDoc[id].artist.tags.tag[i].name; //artist tags 
					} catch (e) {lastfm_data[id][3][i] = "";	}

					try {
						lastfm_data[id][4][i] = lastfm_xmlDoc[id].artist.similar.artist[i].name; //similar artists
					} catch (e) {
						lastfm_data[id][4][i] = "no data";
					}
				}
				
			} catch (e) {
				CorrectedData[id] = "~no data";
			}
			
			break;
		case 2: // storing auto-corrected album name
			try {
				CorrectedData[id] = lastfm_xmlDoc[id].album.name;
			} catch (e) {
				CorrectedData[id] = "~no data";
			}
			break;
		case 3: // storing auto-corrected track name and LOVED state
			try {
				CorrectedData[id] = lastfm_xmlDoc[id].track.name;
				CorrectedData[1] = lastfm_xmlDoc[id].track.artist.name;
			} catch (e) {
				CorrectedData[id] = "~no data";
			}
			try{
				lastfm_data[id][3] = lastfm_xmlDoc[id].track.userloved;
			}catch (e) {lastfm_data[id][3] = "0"; console.log ('[ERR]LOVED TAG NOT FOUND, resetting value to: ' + lastfm_data[id][3]); }
			break;
		}
	}
	
	for (i = 0; i < TLs.length; i++) {
		TLs[i].NeedReset = true;
	}
	//console.log ('=>>> LFM stats USERcounters \n   ...artist stats: '+lastfm_data[1][1]+'\n   ...album stats: '+lastfm_data[2][1]+'\n   ...track stats: '+lastfm_data[3][1]+'\n   ...Loved tag: '+lastfm_data[3][3]+'\n^');
	window.Repaint();
}


function _lastfm() {
	for (let id = 0; id <= 4; id++) {
		this.xmlhttp = lastfm_xmlhttp[id] = new ActiveXObject('Microsoft.XMLHTTP');	
	}

	this.get = (method, id, callback) => {
		//lastfm_xmlhttp[id] = new ActiveXObject('Microsoft.XMLHTTP');	
		var tr_data;
		switch(method) {
		case 'user.getinfo':
		case 'artist.getinfo':
			tr_data = encodeURIComponent(np[0]) + '&autocorrect=1';
			break;
		case 'album.getinfo':
			tr_data = encodeURIComponent(np[0]) + '&album=' + encodeURIComponent(np[1]);
			break;
		case 'track.getinfo':
			tr_data = encodeURIComponent(CorrectedData[1]? CorrectedData[1] : np[0]) + '&track=' + encodeURIComponent(np[2]) + '&autocorrect=1';
			//tr_data = encodeURIComponent(np[0]) + '&track=' + encodeURIComponent(np[2]) + '&autocorrect=1';
			//lfm_define_artist() ? tr_data = encodeURIComponent( CorrectedData[1] ) + '&track=' + encodeURIComponent(np[2]) + '&autocorrect=1' :tr_data = encodeURIComponent(np[0]) + '&track=' + encodeURIComponent(np[2]) + '&autocorrect=1';
			//console.log ('getinfo track url ===> ' + tr_data);
			break;
		default:
			return;
		}
		let data = "http://ws.audioscrobbler.com/2.0?api_key=" + api_key + "&username=" + username + "&user=" + username + "&method=" + method + "&artist=" + tr_data +"&format=json&s=" + Math.random();
		
		lastfm_xmlhttp[id].open("GET", data, true);
		lastfm_xmlhttp[id].setRequestHeader("User-Agent", useragent);
		lastfm_xmlhttp[id].send();
		lastfm_xmlhttp[id].onreadystatechange = () => {
			if (lastfm_xmlhttp[id].readyState == 4) { // 'DONE' state
				//console.log ('_LFM_GET_CALLED id = ' + id + ' ' + data);
				lfm_parse_data(id, callback);
			}
		}
	}
	
	this.post = (method) => {
		metadb = OutputMetadb();
		let artist_sig	= CorrectedData[1] && CorrectedData[1] != "~no data" ? CorrectedData[1] : fb.TitleFormat("%artist%").EvalWithMetadb(metadb)//Eval(metadb, "%artist%");
		let artist		= encodeURIComponent( artist_sig );//.replace(/%20/g,'+');
		let track_sig		= CorrectedData[3] && CorrectedData[3] != "~no data" ? CorrectedData[3] : fb.TitleFormat("%title%").EvalWithMetadb(metadb);
		let track = encodeURIComponent( track_sig );//.replace(/%20/g,'+');
		let api_sig, data;
		
		switch(method) {
		case 'track.love':
		case 'track.unlove':
			console.log ('\n > track sig contains: \n  .. artist sig: [' + artist_sig + '] - track title sig: [' + track_sig + '] \n  .. URI artist: [' + artist + '] - URI track title: [' + track + '] \n ^');
			api_sig = MD5('api_key' + api_key + 'artist' + artist_sig + 'method' + method + 'sk' + key + 'track' + track_sig + secret);
			data = 'method=' + method + '&api_key=' + api_key + '&api_sig=' + api_sig + '&sk=' + key + '&artist=' + artist + '&track=' + track;
			//data = "method=track.unlove&api_key=" + api_key + "&api_sig=" + api_sig + "&artist=" + artist + "&track=" + track + "&sk=" + key;
			break;
		case 'auth.getMobileSession':
			api_sig = MD5('api_key' + api_key + 'methodauth.getMobileSessionpassword' + password + 'username' + username + secret);
			console.log ( '=> creating api signature hash = ' + api_sig);
			data = 'password=' + password + '&username=' + username + '&method=' + method +'&format=json&api_key=' + api_key + '&api_sig=' + api_sig;
			break;
		case 'track.getinfo':
			let tr_data = encodeURIComponent(CorrectedData[1]? CorrectedData[1] : np[0]) + '&track=' + encodeURIComponent(np[2]) + '&autocorrect=1';
			data = "http://ws.audioscrobbler.com/2.0?api_key=" + api_key + "&username=" + username + "&user=" + username + "&method=" + method + "&artist=" + tr_data +"&format=json&s=";// + Math.random();
			break;
		default:
			return;
		}
		this.xmlhttp.open('POST', "https://ws.audioscrobbler.com/2.0/", true);
		this.xmlhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
		this.xmlhttp.setRequestHeader('User-Agent', useragent);
		this.xmlhttp.send(data);
		this.xmlhttp.onreadystatechange = () => {
			if (this.xmlhttp.readyState == 4) {
				this.done(method, id);
			}
		}
	}
	this.get_errors = () => {
		let jsDoc = JSON.parse(this.xmlhttp.responseText);
		if (jsDoc.error) {
			if (jsDoc.error == 9) { // sessioni key invalid
				update_option("skey", ""); // clearing session key
				key = false;
				console.log("[ERR] got error code 9, session key reset");
			}
			fb.ShowConsole();
			loveIMG_state = 2; // FAILED
			window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area
			return console.log('[ERR] Last.fm server error: ' + jsDoc.message);
		}
	}
	this.done = (method, id) => {
		switch (method) {
		case 'track.love':
			if (this.xmlhttp.responseText.includes('ok')) {
				console.log('[f] Track loved successfully.');
				loveIMG_state = 0; // - everything OK
				Userloved = 1;
				lastfm_data[3][3] = Userloved; // writing in existing .getinfo array... dirty but it works!
				m_hover = false;
				RateTrack(5);
				console.log("... checking array value for love = " + lastfm_data[3][3]);
				window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area
				return;
			} else {
				this.get_errors();
			}
			break;
		case 'track.unlove':
			if (this.xmlhttp.responseText.includes('ok')) {
				console.log('[f] Track unloved successfully.');
				loveIMG_state = 0; // OK
				Userloved = 0;
				lastfm_data[3][3] = Userloved; 
				m_hover = false;
				RateTrack("");
				console.log("... checking array value for (UN)love = " + lastfm_data[3][3]);
				window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area
				return;
			} else {
				this.get_errors();
			}
			break;
		case 'auth.getMobileSession':
			if (this.xmlhttp.status == 200) { //success
				console.log('[API] AUTH status 200 - success ');
				if (this.xmlhttp.responseText.includes('key')) {
					//console.log('[API] reading "key " tag');
					try { // reading <key> tag
						let jsDoc = JSON.parse(this.xmlhttp.responseText);
						key = jsDoc.session.key;
					} catch (e) {
						key = null;
						this.get_errors();
					} finally {
						console.log('[API] => session key response recieved \n session key == ' +key );
					}
				}
					
				if (key && key.length == 32) { 
					update_option("skey", key); // saving session key
					console.log('[API] writing skey ' + key + ' to cfg.ini' );
					loveIMG_state = 0; 
					window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area
				}
			}
			if (this.xmlhttp.status >= 400) { //error statuses
				this.get_errors();
				console.log('[API] AUTH status 400 - error, no data recieved');
			}
			break;
		case 'track.getinfo':
			if (this.xmlhttp.status == 200) { //success
				try {lastfm_xmlDoc[3] = JSON.parse(lastfm_xmlhttp[3].responseText);} catch (e) {};
				try {Userloved = lastfm_xmlDoc[3].track.userloved;
				} catch (e) {};
				if (this.xmlhttp.responseText.includes('ok')) {
					if (Userloved) {
						loveIMG_state = 0;
						GotInfo = 1;
					}
				} else {
					loveIMG_state = 2;
					GotInfo = 0; // ??? 
				}
				window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area
			}
			/*
			if (this.xmlhttp.status >= 400) { //error statuses
				error_count++;
				lastfm_status++;
			}*/
			break;
		}
	}
}
var _LFM = new _lastfm();


// Check if the track is LOVED
function lastfm_update_love() {
	let metapath
	metadb = OutputMetadb();
	try { metapath = metadb.Path ? metadb.Path : 0; } // making sure we don't check some URL link from the playlist
	catch (e) { metapath = 0; }
    //metadb = metadb ? metadb : OutputMetadb();
	_LFM.post('track.getinfo');
	this.check_love = () => {
		if ( metadb && username.length > 3 && api_key.length > 1 ) {
			if (wait == 0) {
				try { 		Userloved = lastfm_data[3][3];} // reading "userloved" tag from the array we already have
				catch (e) {	Userloved = 0;}
			} else { 
				Userloved = 0;
			}
			if (Userloved) {
				loveIMG_state = 0;
				GotInfo = 1;
			}
			window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area
		} 
		else {
			loveIMG_state = 2;
			GotInfo = 0; // ??? 
			window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area
		}
		//console.log("[f] => checking USERLOVED in lastfm_CHECK_LOVE for track: \n[" + CorrectedData[1] + "] | ["+ np[2] + "]\n - LOVE array value is => " + lastfm_data[3][3] + "\n  - calculated value => " +Userloved);
	}

    if ( metapath && check_data() ) {
		this.check_love();
		_LFM.post('track.getinfo');
		//console.log("= CHECKING love icon in lastfm_update_love() = " + Userloved );
    }
}

function lastfm_reset_love() {
	console.log ('[f] REFRESH LOVE ICON');
    m_hover = 0;
    loveIMG_state = 0;
    //GotInfo = 0;
    Userloved = 0; //???
	window.RepaintRect(hofset, vofset, imgw, imgw+2);
}

// === LASTFM FUNCTIONS }}

// === EVENTS FUNCTIONS {{
function on_init() {
	if (!key && !api_key && !secret) { // some default keys combination
		console.log('[API] Load default set of Last.fm api keys');
		//update_option("api_key", "179b25d95e633097ec682c58b4a993ec");
		update_option("api_key", "96d047d302a8707f3a7410873466dbfd");
		update_option("secret", "3afdcf3ccad058a82202544549cb141b");
		window.Reload();
	}
	WaitTimer = new _waitTimer();
	for (let id = 0; id <= 4; id++) {
		lastfm_data[id] = new Array(4);
		switch (id) {
		case 1 :
			lastfm_data[id][3] = new Array();
			lastfm_data[id][4] = new Array();
			for (let i = 0; i < 5; i++) {
				lastfm_data[id][3][i] = "";
				lastfm_data[id][4][i] = "";
			}
			break;
		default:
			if (id <= 3) {
				for (let n = 0; n <= 5; n++) {
					lastfm_data[id][n] = 0;
				}
			}
			break;
		}
	}
}
on_init();
 
function on_size() {
	if (!window.Width || !window.Height) return;
	ww = window.Width;
	wh = window.Height;

	GetCoordinates();
	CursorFollow(CurrentMode);
}

var userdata_refresh;
function on_paint(gr) {
	sum_height = 0;
	gr.SetTextRenderingHint(5);
	if (!check_data()){
		gr.GdiDrawText("Last.fm panel initiated", font_header, RGB(190,0,0), 0, -80, ww, wh, DT_CENTER | DT_VCENTER | DT_CALCRECT | DT_NOPREFIX);
		if (username.length == 0) {
			gr.GdiDrawText("Please enter your\n USERNAME and PASSWORD.", font_normal, normal_color, 0, -40, ww, wh, DT_CENTER | DT_VCENTER | DT_CALCRECT | DT_NOPREFIX);
			gr.GdiDrawText("Reload panel!", font_header, normal_color, 0, 40, ww, wh, DT_CENTER | DT_VCENTER | DT_CALCRECT | DT_NOPREFIX);
			userdata_refresh = 1;
			//return;
		}
		if (api_key.length != 32 || secret.length != 32) {
			gr.GdiDrawText("API or SECRET key is missing! \n Use context menu to set it up.", font_normal, normal_color, 0, 0, ww, wh, DT_CENTER | DT_VCENTER | DT_CALCRECT | DT_NOPREFIX);
			userdata_refresh = 1;
			return;
		}
		return;
	}
	if (wait == 0) {
		//draw last.fm logo
		
		//gr.FillGradRect(124, tm + Y_OFFSET-1,120,60,90,RGBA(210,19,9,255),RGB(170,19,9,255),1); // red bg
		//gr.DrawRect(123, tm + Y_OFFSET-1, 122, 60, 2, RGB(30,30,30)); 
		
		//gr.FillGradRect(124,tm + Y_OFFSET-1,61,1,180,RGB(30,30,30),RGB(210,19,9)); // border top left
		//gr.FillGradRect(183,tm + Y_OFFSET-1,61,1,0,RGB(30,30,30),RGB(210,19,9)); // border top right
		
		//gr.FillGradRect(124,tm + Y_OFFSET-1+60,61,1,180,RGB(30,30,30),RGB(170,19,9)); // border bottom left
		//gr.FillGradRect(183,tm + Y_OFFSET-1+60,61,1,0,RGB(30,30,30),RGB(170,19,9)); // border bottom right
		
		gr.FillGradRect(ww/2-1,103,ww/2-5,1,0,RGB(90,90,90),RGB(255,255,255)); // track count border left
		gr.FillGradRect(5,103,ww/2-5,1,180,RGB(90,90,90),RGB(255,255,255)); // track count border right
		
		//gr.DrawImage(img_lastfm_logo_red, (ww - 110), tm + Y_OFFSET, 100, 30, 0, 0, 900, 269);
		gr.DrawImage(img_lastfm_logo_red, 122, tm + Y_OFFSET + 16, 119, 30, 0, 0, 119, 30);

		
		sum_height += 5;
		
		// plays ======================================================================
		for (i = 0; i <= 3; i++) {
			charcounter = 0;
			spcounter = 0;
 
			switch (i) {
				case 0:
					txt_plays = " plays";
					break;
				case 1:
					txt_plays = " per day";
					break;
				case 2:
					txt_plays = " per week";
					break;
				case 3:
					txt_plays = " per month";
					break;
			}
 
			if (longeststr.length < lastfm_data[0][i].length) longeststr = lastfm_data[0][i];
 
			for (j = 0; j < lastfm_data[0][i].length; j++) {
				if (lastfm_data[0][i].substring((j), j + 1) != " ") {
					gr.DrawImage(img_lastfm_flip, lm + charcounter * 11 + spcounter * 5, sum_height + Y_OFFSET, img_lastfm_flip.Width, img_lastfm_flip.Height, 0, 0, img_lastfm_flip.Width, img_lastfm_flip.Height);
					charcounter++;
				} else {
					spcounter++;
				}
				gr.GdiDrawText(lastfm_data[0][i].substring((j), j + 1), font_num, RGB(255, 255, 255), lm + 2 + (charcounter - 1) * 11 + spcounter * 5, sum_height - 1 + Y_OFFSET, ww, wh, DT_TOP | DT_LEFT);
			}
			gr.GdiDrawText(txt_plays, font_num, normal_color, lm + charcounter * 11 + spcounter * 5 + 3, sum_height - 1 + Y_OFFSET, ww, wh, DT_TOP | DT_LEFT);
			sum_height += img_lastfm_flip.Height + 3;
		}
		sum_height += font_header.Height + 18;

		for (i = 0; i < 3; i++) {
			TLs[i].y = sum_height;
 
			if (TLs[i].NeedReset) {
				if (CorrectedData[i + 1] != "~no data") {
					//replacing artist and title with autocorrected counterparts.
					text_Ws[i] = Math.ceil(gr.MeasureString(CorrectedData[i + 1] == np[i] ? np[i] : CorrectedData[i + 1] + " [*]", font_normal, 0, 0, ww - 50 - lm - rm - 20, wh, LineStrFmt).Width);
					text_Hs[i] = Math.ceil(gr.MeasureString(CorrectedData[i + 1] == np[i] ? np[i] : CorrectedData[i + 1] + " [*]", font_normal, 0, 0, ww - 50 - lm - rm - 20, wh, LineStrFmt).Height);
 
					switch (i) {
						case 0:
							TLs[i].OnClick = function () {
								wsShell.Run("http://www.last.fm/music/" + encodeURIComponent(CorrectedData[1]))
							};
							break;
						case 1:
							TLs[i].OnClick = function () {
								wsShell.Run("http://www.last.fm/music/" + encodeURIComponent(CorrectedData[1]) + "/" + encodeURIComponent(CorrectedData[2]))
							};
							break;
						case 2:
							TLs[i].OnClick = function () {
								wsShell.Run("http://www.last.fm/music/" + encodeURIComponent(CorrectedData[1]) + "/" + encodeURIComponent(CorrectedData[2]) + "/" + encodeURIComponent(CorrectedData[3]))
							};
							break;
					}
 
					TLs[i].x = 50 + lm;
					TLs[i].Width = text_Ws[i] + 8;
					TLs[i].Height = text_Hs[i];
					TLs[i].label = CorrectedData[i + 1] == np[i] ? np[i] : CorrectedData[i + 1] + " [*]";
					TLs[i].tiptext = CorrectedData[i + 1] == np[i] ? "" : "Auto-corrected from: " + "'" + np[i] + "'";
					TLs[i].NeedReset = false;
				} else {
					text_Ws[i] = Math.ceil(gr.MeasureString(np[i], font_normal, 0, 0, ww - 50 - lm - rm - 20, wh, LineStrFmt).Width);
					text_Hs[i] = Math.ceil(gr.MeasureString(np[i], font_normal, 0, 0, ww - 50 - lm - rm - 20, wh, LineStrFmt).Height);
 
					switch (i) {
						case 0:
							TLs[i].OnClick = function () {
								wsShell.Run("http://www.last.fm/music/" + encodeURIComponent(np[0]))
							};
							break;
						case 1:
							TLs[i].OnClick = function () {
								wsShell.Run("http://www.last.fm/music/" + encodeURIComponent(np[0]) + "/" + encodeURIComponent(np[1]))
							};
							break;
						case 2:
							TLs[i].OnClick = function () {
								wsShell.Run("http://www.last.fm/music/" + encodeURIComponent(np[0]) + "/" + encodeURIComponent(np[1]) + "/" + encodeURIComponent(np[2]))
							};
							break;
					}
					TLs[i].x = 50 + lm;
					TLs[i].Width = text_Ws[i] + 8;
					TLs[i].Height = text_Hs[i];
					TLs[i].label = np[i];
					TLs[i].tiptext = "";
					TLs[i].NeedReset = false;
				}
			}
			TLs[i].Draw(this.x, this.y, gr);

			switch (i) {
				case 0:
					txt_t = "Artist:";
					break;
				case 1:
					txt_t = "Album:";
					break;
				case 2:
					txt_t = "Track:";
					break;
			}
			gr.GdiDrawText(txt_t, font_label, normal_color, lm, sum_height + 2 + Y_OFFSET, 50, wh);
			sum_height += text_Hs[i] + 3;
		}
 
		sum_height += 7;
 
		// tags ======================================================================
		gr.GdiDrawText("Artist", font_label, normal_color, lm, sum_height + 2 + Y_OFFSET, 50, wh);
		gr.GdiDrawText("tags:", font_label, normal_color, lm, sum_height + 2 + font_label.Height + Y_OFFSET, 50, wh);
		linecounter = 1;
 
		if (lastfm_data[1][3][0] != "no data") {
			for (i = 0; i < 5; i++) {
				text_Ws[i + 3] = Math.ceil(gr.MeasureString(lastfm_data[1][3][i], font_normal, 0, 0, ww - 50 - lm - rm - 20, wh, LineStrFmt).Width);
				text_Hs[i + 3] = Math.ceil(gr.MeasureString(lastfm_data[1][3][i], font_normal, 0, 0, ww - 50 - lm - rm - 20, wh, LineStrFmt).Height);

				TLs[i + 3].x = i == 0 ? 50 + lm : (TLs[i + 2].x + text_Ws[i + 2] + 8 + text_Ws[i + 3] + 8 + 1 < ww - rm - 20 ? TLs[i + 2].x + text_Ws[i + 2] + 11 : 50 + lm);
				TLs[i + 3].y = i == 0 ? sum_height : (TLs[i + 2].x + text_Ws[i + 2] + 8 + text_Ws[i + 3] + 8 + 1 < ww - rm - 20 ? TLs[i + 2].y : sum_height + font_normal.Height + 3);
				linecounter += (TLs[i + 2].x + text_Ws[i + 2] + 8 + text_Ws[i + 3] + 8 + 1 < ww - rm - 20) || i == 0 ? 0 : 1;

				if (TLs[i + 3].NeedReset) {
					switch (i) {
						case 0:
							TLs[i + 3].OnClick = function () {
								wsShell.Run("http://www.last.fm/tag/" + encodeURIComponent(lastfm_data[1][3][0]))
							};
							break;
						case 1:
							TLs[i + 3].OnClick = function () {
								wsShell.Run("http://www.last.fm/tag/" + encodeURIComponent(lastfm_data[1][3][1]))
							};
							break;
						case 2:
							TLs[i + 3].OnClick = function () {
								wsShell.Run("http://www.last.fm/tag/" + encodeURIComponent(lastfm_data[1][3][2]))
							};
							break;
						case 3:
							TLs[i + 3].OnClick = function () {
								wsShell.Run("http://www.last.fm/tag/" + encodeURIComponent(lastfm_data[1][3][3]))
							};
							break;
						case 4:
							TLs[i + 3].OnClick = function () {
								wsShell.Run("http://www.last.fm/tag/" + encodeURIComponent(lastfm_data[1][3][4]))
							};
							break;
					}

					TLs[i + 3].Width = text_Ws[i + 3] + 8;
					TLs[i + 3].Height = text_Hs[i + 3];
					TLs[i + 3].label = lastfm_data[1][3][i];
					TLs[i + 3].tiptext = "";
					TLs[i + 3].NeedReset = false;
				}
				TLs[i + 3].Draw(0, 0, gr);
 
				if (i == 0) sum_height += gr.MeasureString(lastfm_data[1][3][i], font_normal, 0, 0, ww - 50 - lm - rm - 20, wh, LineStrFmt).lines > 1 ? text_Hs[i + 3] - font_normal.Height : 0;
				else sum_height += (TLs[i + 2].x + text_Ws[i + 2] + 8 + text_Ws[i + 3] + 8 + 1 < ww - rm - 20) ? 0 : text_Hs[i + 3] + 3;
			}
		} else {
			for (i = 0; i < 5; i++) {
				TLs[i + 3].show = false;
			}
			gr.GdiDrawText("No tags recieved", font_normal, normal_color, lm + 50, sum_height + 2 + Y_OFFSET, ww, wh);
		}
 
		sum_height += linecounter == 1 ? font_normal.Height * 2 + 6 : font_normal.Height + 6;
		// similar ======================================================================
 
		gr.GdiDrawText("Similar", font_label, normal_color, lm, sum_height + 2 + Y_OFFSET, 50, wh);
		gr.GdiDrawText("artists:", font_label, normal_color, lm, sum_height + 2 + font_label.Height + Y_OFFSET, 50, wh);
		linecounter = 1;
 
		if (lastfm_data[1][4][0] != "no data" || lastfm_data[1][4][0] == "") {
			for (i = 0; i < 5; i++) {
				text_Ws[i + 8] = Math.ceil(gr.MeasureString(lastfm_data[1][4][i], font_normal, 0, 0, ww - 50 - lm - rm - 20, wh, LineStrFmt).Width);
				text_Hs[i + 8] = Math.ceil(gr.MeasureString(lastfm_data[1][4][i], font_normal, 0, 0, ww - 50 - lm - rm - 20, wh, LineStrFmt).Height);

				TLs[i + 8].x = i == 0 ? 50 + lm : (TLs[i + 7].x + text_Ws[i + 7] + 8 + text_Ws[i + 8] + 8 + 1 < ww - rm - 20 ? TLs[i + 7].x + text_Ws[i + 7] + 11 : 50 + lm);
				TLs[i + 8].y = i == 0 ? sum_height : (TLs[i + 7].x + text_Ws[i + 7] + 8 + text_Ws[i + 8] + 8 + 1 < ww - rm - 20 ? TLs[i + 7].y : sum_height + font_normal.Height + 3);
				linecounter += (TLs[i + 7].x + text_Ws[i + 7] + 8 + text_Ws[i + 8] + 8 + 1 < ww - rm - 20) || i == 0 ? 0 : 1;
 
				if (TLs[i + 8].NeedReset) {
					switch (i) {
						case 0:
							TLs[i + 8].OnClick = function () {
								wsShell.Run("http://www.last.fm/music/" + encodeURIComponent(lastfm_data[1][4][0]))
							};
							break;
						case 1:
							TLs[i + 8].OnClick = function () {
								wsShell.Run("http://www.last.fm/music/" + encodeURIComponent(lastfm_data[1][4][1]))
							};
							break;
						case 2:
							TLs[i + 8].OnClick = function () {
								wsShell.Run("http://www.last.fm/music/" + encodeURIComponent(lastfm_data[1][4][2]))
							};
							break;
						case 3:
							TLs[i + 8].OnClick = function () {
								wsShell.Run("http://www.last.fm/music/" + encodeURIComponent(lastfm_data[1][4][3]))
							};
							break;
						case 4:
							TLs[i + 8].OnClick = function () {
								wsShell.Run("http://www.last.fm/music/" + encodeURIComponent(lastfm_data[1][4][4]))
							};
							break;
					}

					TLs[i + 8].Width = text_Ws[i + 8] + 8;
					TLs[i + 8].Height = text_Hs[i + 8];
					TLs[i + 8].label = lastfm_data[1][4][i];
					TLs[i + 8].tiptext = "";
					TLs[i + 8].NeedReset = false;
				}
				TLs[i + 8].Draw(0, 0, gr);
 
				if (i == 0) sum_height += gr.MeasureString(lastfm_data[1][4][i], font_normal, 0, 0, ww - 50 - lm - rm - 20, wh, LineStrFmt).lines > 1 ? text_Hs[i + 8] - font_normal.Height : 0;
				else sum_height += (TLs[i + 7].x + text_Ws[i + 7] + 8 + text_Ws[i + 8] + 8 + 1 < ww - rm - 20) ? 0 : text_Hs[i + 8] + 3;
			}
		} else {
			for (i = 0; i < 5; i++) {
				TLs[i + 8].show = false;
			}
			gr.GdiDrawText("No artists received", font_normal, normal_color, lm + 50, sum_height + 2 + Y_OFFSET, ww, wh);
		}
 
		sum_height += linecounter == 1 ? font_normal.Height * 2 + 2 : font_normal.Height + 2;
		GetCoordinates(); //run this when all buttons are reset
 
		//===================================================== user stats & labels
	    var stats_y = 70
		
	    for (id = 1; id <= 3; id++) {
			charcounter = 0;
			spcounter = 0;
			var col_offset = (id == 1 ? 0 : (id == 2 ? 90 : 175));
			var line_offset = 16
			for (j = 0; j < lastfm_data[id][1].length; j++) {
				if (lastfm_data[id][1].substring((j), j + 1) != " ") {
					gr.DrawImage(img_lastfm_flip, lm + charcounter * 11 + spcounter * 5 + col_offset, line_offset + stats_y + Y_OFFSET, img_lastfm_flip.Width, img_lastfm_flip.Height, 0, 0, img_lastfm_flip.Width, img_lastfm_flip.Height);
					charcounter++;
				} else {
					spcounter++;
				}
				gr.GdiDrawText(lastfm_data[id][1].substring((j), j + 1), font_num, RGB(255, 255, 255), lm + (charcounter - 1) * 11 + spcounter * 5 + 2 + col_offset, line_offset + stats_y - 1 + Y_OFFSET, ww, wh);
			}
 
			switch (id) {
				case 1:
					txt_tt = "Artist:";
					break;
				case 2:
					txt_tt = "Album:";
					break;
				case 3:
					txt_tt = "Track:";
					break;
			}
 
			gr.GdiDrawText(txt_tt, font_label, normal_color, lm + col_offset, stats_y - 1 + Y_OFFSET, ww, wh);
			stats_y += 0;//18;
	    }
	    //===================================================== LFMLOVE
	    gr.SetSmoothingMode(2);
	    gr.SetTextRenderingHint(5);
	    //console.log( 'm_hover = ' + m_hover + ' Userloved = ' + Userloved );
	    var icon_x = hofset;
	    var icon_y = vofset;
	    
	    if ( !loveIMG_state ) {
			if ( !check_data() ) {
				gr.DrawImage( key_big_image, icon_x, icon_y, key_big_image.Width, key_big_image.Height, 0, 0, key_big_image.Width, key_big_image.Height);
			}
			else {
				if ( !GotInfo ) {
					if ( info_image ) gr.DrawImage( info_image, icon_x, icon_y, info_image.Width, info_image.Height, 0, 0, info_image.Width, info_image.Height);
				}
				else if ( m_hover ) {
				gr.DrawImage( m_hover == 1 ? heart_delete : m_hover == 2 ? heart_add : null, icon_x, icon_y, heart_grey.Width, heart_grey.Height, 0, 0, heart_grey.Width, heart_grey.Height);
				}
				else if ( Userloved == 1 ) {
				if ( heart_red ) gr.DrawImage( heart_red, icon_x, icon_y, heart_red.Width, heart_red.Height, 0, 0, heart_red.Width, heart_red.Height);
				else gr.GdiDrawText( '�', font_header, RGB(255,0,0), 0, 0, window.Width, window.Height, 0x00000000 | 0x00000004 | 0x00000400 | 0x00008000);
				}
				else if ( heart_grey ) gr.DrawImage( heart_grey, icon_x, icon_y, heart_grey.Width, heart_grey.Height, 0, 0, heart_grey.Width, heart_grey.Height);
				else gr.GdiDrawText( '�', font_header, RGB(128,128,128), 0, 0, window.Width, window.Height, 0x00000000 | 0x00000004 | 0x00000400 | 0x00008000);

				if ( !key && key_image && check_data() ) gr.DrawImage( key_image, icon_x, icon_y, key_image.Width, key_image.Height, 0, 0, key_image.Width, key_image.Height, angle = 0, alpha = 255);
			}
	    }
	    else {
			try {
				var status_image = gdi.Image(imgPath + status_images[ loveIMG_state ] );
			}
			catch(e) {}
			//if ( loveIMG_state != 2 && disconnect_image && g_hover ) gr.DrawImage( disconnect_image, ( window.Width - disconnect_image.Width ) / 2, ( window.Height - disconnect_image.Height ) / 2, disconnect_image.Width, disconnect_image.Height, 0, 0, disconnect_image.Width, disconnect_image.Height, angle = 0, alpha = 255);
			if ( status_image ) gr.DrawImage( status_image, icon_x, icon_y, status_image.Width, status_image.Height, 0, 0, status_image.Width, status_image.Height, angle = 0, alpha = 255);
			else gr.GdiDrawText( '...', font_header, RGB(128,128,128), icon_x, icon_y, window.Width, window.Height, 0x00000000 | 0x00000004 | 0x00000400 | 0x00008000);
	    }
	    //===================================================== LFMLOVE   
	} else if (wait == 1) {
		gr.GdiDrawText("Grabbing last.fm data.\n Hold on!", font_normal, normal_color, 0, 0, ww, wh, DT_CENTER | DT_VCENTER | DT_CALCRECT | DT_NOPREFIX);
		return;
	} else if (wait == -1) {
		gr.GdiDrawText("Artist: " + np[0] + "\n Album: " + np[1] + "\n Track: " + np[2] + "\n \n Something went wrong :( \n No Data received.", font_normal, normal_color, 0, 0, ww, wh, DT_CENTER | DT_VCENTER | DT_CALCRECT | DT_NOPREFIX);
	} else if (wait == -2) {
		gr.GdiDrawText("No track specified", font_normal, normal_color, 0, 0, ww, wh, DT_CENTER | DT_VCENTER | DT_CALCRECT | DT_NOPREFIX);
	}
}
 
function on_playback_new_track() {
	if(CurrentMode == 2){
		WaitTimer.Stop();
		//WaitTimer.Start(); // test
		MetaDB = fb.GetNowPlaying();
		if (!MetaDB) return;
		FOCUSFLAG = false;
		np = [fb.TitleFormat("%artist%").EvalWithMetadb(MetaDB), fb.TitleFormat("%album%").EvalWithMetadb(MetaDB), fb.TitleFormat("%title%").EvalWithMetadb(MetaDB)];
		
		if (np[0] == "?" && np[1] == "?") {
			wait = -2;
			window.Repaint();
			return;
		/*} else if (CorrectedData[1]) {
			np[0] = CorrectedData[1];
			window.Repaint();
			return;*/
		}
		lastfm_status = 0;
		wait = 1;
		//lfm_startWork();
		lfm_get_artist();
		window.Repaint();
	};
}
 
 
function on_item_focus_change() {
	if(CurrentMode == 3 || (CurrentMode == 2 && !fb.IsPlaying && !fb.IsPaused )){
		WaitTimer.Stop();
		WaitTimer.Start();
		//lastfm_update_love(); // included in .Start
	}
}
 
function on_playback_stop(reason) {
	if (!reason || reason == 1) {
		if(CurrentMode == 2 && !FOCUSFLAG){
			WaitTimer.Stop();
			WaitTimer.Start();
		}
	}
}

function on_mouse_move(x, y) {
	if (window.Width < 185 || window.Height < 100) return;
	if (userdata_refresh) {
		XYref = ((window.Width/2-50 <= x) && (x <= window.Width/2+50) && (window.Height/2+20 <= y) && (y <= 60+window.Height/2));
		if (XYref) {window.SetCursor(IDC_HAND);} else {window.SetCursor(IDC_ARROW);}
	}
	if (wait != 0) return;
	ww = window.Width;
	wh = window.Height;
	XYinLove = ((hofset <= x) && (x <= hofset + imgw) && (vofset <= y) && (y <= vofset + imgw));
	//XYinLogo = ((122 <= x) && (x <= ww) && (tm + Y_OFFSET + 16 <= y) && (y <= wh));
		
	if ( key && OutputMetadb() && GotInfo && !m_hover && XYinLove ) {
		window.SetCursor( IDC_HAND );
		tooltip.Text = "Middle click to update info\nLeft click to love or unlove";
		tooltip.Activate();
		if ( heart_delete && Userloved == 1 ) m_hover = 1;
		else if ( heart_add && Userloved == 0 ) m_hover = 2;
		//window.Repaint();
		//window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area
	}
	else if ( key && OutputMetadb() && !GotInfo && !g_hover && XYinLove ) {
		window.SetCursor( IDC_HAND );
		tooltip.Text = "Left click to get track info";
		tooltip.Activate();
		g_hover = 1;
		//window.Repaint();
		//window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area
	}
	else if ( !g_hover && XYinLove ) {
	    if ( check_data() ) {
			window.SetCursor( IDC_HAND );
			if ( !tooltip.Text ) { 
				tooltip.Text = 'You\'ve entered all necessary info. It should be fine now. Click to authenticate.';
				tooltip.Activate();
			}
	    }
	    else {
			window.SetCursor( IDC_HAND );
			tooltip.Text = 'Click to enter your private information';
			tooltip.Activate();
	    }
	    g_hover = 1;
	    //window.Repaint();
	    //window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area
	}
	
	if (XYinLove) {
	    if (!love_timer) love_timer = window.SetInterval(function() {
			window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area   
	    }, 100); 
	} else {
		//if (!XYinLove) {
			m_hover = false;
			g_hover = false;
			tooltip.Text = '';
			tooltip.Deactivate();
			//window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area

	    /*
	    love_timeout = window.SetTimeout(function() { // timeout to kill timer
			if (love_timer) window.ClearInterval(love_timer);
		    love_timer = false;
		    window.RepaintRect(hofset, vofset, imgw*5, imgw+5); //Repaint RATING area;
	    }, 100);
	    */
			//window.SetCursor( IDC_ARROW );
	    if (d_link) {
		    if (d_link.isXYok(x, y)) {
				if (d_link.state != 2) d_link.ChangeState(2);
		    } else if (d_link.state != 1) d_link.ChangeState(1);
	    } else {
			for (var i = 0; i < TLs.length; i++)
			if (TLs[i].isXYok(x, y) && TLs[i].show) {
				if (h_link != TLs[i]) {
				if (h_link) h_link.ChangeState(0);
				h_link = TLs[i];
				if (h_link != TLs[13]) window.SetCursor(IDC_HAND);
				h_link.ChangeState(1);
				}
				break;
			}
			if (i == TLs.length) {
				if (h_link) {
					if (h_link) h_link.ChangeState(0);
					h_link = undefined;
					//window.SetCursor(IDC_ARROW);
				}
				window.SetCursor(IDC_ARROW);
			}
	    }
	}
}
 
function on_mouse_lbtn_down(x, y) {
	if (window.Width < 185 || window.Height < 100) return;
	if (h_link && !d_link) {
		d_link = h_link;
		d_link.ChangeState(2);
	};
}
 
function on_mouse_lbtn_up(x, y) {
	if (window.Width < 185 || window.Height < 100) return;
	if (userdata_refresh && XYref) window.Reload();
	if (d_link) {
		if (d_link.state == 2) {
			d_link.OnClick();
		}
		d_link = undefined;
		on_mouse_move(x, y);
	}
	
	if (XYinLove) {
		switch (true) {
		case !check_data():
			show_context_menu(x, y);
			return console.log('Last.fm username not set or api key is missing.');
		case loveIMG_state != 1:
			switch (true) {
			case !key:
				_LFM.post('auth.getMobileSession');
				break;
			case !GotInfo:
				//lastfm_check_love();
				lastfm_update_love();
				break;
			case Userloved == 1:
				lastfm_reset_love();
				_LFM.post('track.unlove'); 
				break;
			case Userloved == 0:
				lastfm_reset_love(); 
				_LFM.post('track.love');
				break;
			default:
				lastfm_reset_love(); 
				window.RepaintRect(hofset, vofset, imgw, imgw+2);
				return;
			}
		}
/*
		if ( !check_data() ) {
			//window.ShowConfigure();
			show_context_menu(x, y);
		}
		else if ( loveIMG_state != 1 ) {
			if ( !key ) { auth_lastfm(); }
			else if ( loveIMG_state ) { lastfm_reset_love(); window.RepaintRect(hofset, vofset, imgw, imgw+2); }
			else if ( !GotInfo ) { lastfm_check_love(); }
			//else if ( Userloved == 1 && key ) { lastfm_unlove(); lastfm_reset_love(); }
			//else if ( Userloved == 0 && key ) { lastfm_reset_love(); lastfm_love(); }
			else if ( Userloved == 1 && key ) { _LFM.post('track.unlove'); lastfm_reset_love(); }
			else if ( Userloved == 0 && key ) { lastfm_reset_love(); _LFM.post('track.love'); }
			else { lastfm_reset_love(); GotInfo = 0; window.RepaintRect(hofset, vofset, imgw, imgw+2); }
		}
*/
	}
}
/*
function on_notify_data( name, love ) {
    if ( name == 'E4101BAA-6B63-451E-B522-431C39897915' ) {
	GotInfo   = 1;
	loveIMG_state = false;
	Userloved = love;
	//window.Repaint();
	window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area
    }
}
 */
function on_mouse_leave() {
	if (window.Width < 185 || window.Height < 100) return;
	if (h_link) {
		h_link.ChangeState(0);
		h_link = undefined;
		window.SetCursor(IDC_ARROW);
	}
	tooltip.Text = "";
}

function on_mouse_mbtn_up(x,y,mask) {
    if ( check_data() && XYinLove) {
		lastfm_reset_love();
		lastfm_update_love();
		window.RepaintRect(hofset, vofset, imgw, imgw+2);
    }
}

var rbtnDown;
function on_mouse_rbtn_down(x, y, vkey) {
	rbtnDown = true;
}
 
function on_mouse_rbtn_up(x, y, vkey) {
	if (window.Width < 185 || window.Height < 100) return false;
	if (rbtnDown) {
		rbtnDown = false;
		if (vkey == MK_SHIFT) {
			return false; // if shift button pressed, show default context menu.
		} else {
			show_context_menu(x, y);
			return true;
		}
	}
}
 
function on_playlist_items_removed(playlist, new_count) {
	on_playlists_changed();
}
 
function on_playlist_switch() {
	on_playlists_changed();
}
 
function on_playlists_changed() {
	on_item_focus_change();
}
/*
function on_metadb_changed() {
	lastfm_update_love();
	window.RepaintRect(hofset, vofset, imgw, imgw+2); //Repaint Love button area
	//window.Repaint();
}
*/
// === EVENTS FUNCTIONS }}

// ===	| lastfm_data arrays // foo_silk-lastfm engine // by Matthijs Brobbel	|
//		| 0				| 1				| 2				| 3				| 
//  id:	| userinfo 		| artistinfo		| albuminfo		| trackinfo		| 
//		-------------------------------------------------------------------------
//	0:	| playcount		| playcount		| playcount		| playcount		|
//	1:	| avg_day		| userplaycount	| userplaycount	| userplaycount	|
//	2:	| avg_week		| listeners		| listeners		| listeners		|
//	3:	| avg_month		| tags			| 0				| userloved		|
//	4:	| joindate		| similar		| 0				| 0				|
//	5:	| avatar			| 0				| 0				| 0				|