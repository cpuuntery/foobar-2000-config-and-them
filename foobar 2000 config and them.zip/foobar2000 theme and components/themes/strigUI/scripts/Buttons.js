//var fso = new ActiveXObject("Scripting.FileSystemObject");
var imgPath = fb.ProfilePath + "themes\\strigUI\\Images\\";

var B = gdi.Image(imgPath + "Buttons\\BUTTON.png");
var PREV = gdi.Image(imgPath + "Buttons\\PREV.png");
var PLAY = gdi.Image(imgPath + "Buttons\\PLAY.png");
var PAUSE = gdi.Image(imgPath + "Buttons\\PAUSE.png");
var NEXT = gdi.Image(imgPath + "Buttons\\NEXT.png");
//var H = gdi.Image(imgPath + "Buttons\\H.png");

var NEXT_ICO = gdi.Image(imgPath + "Buttons\\NEXT_ICO.png");
var PREV_ICO = gdi.Image(imgPath + "Buttons\\PREV_ICO.png");
var PLAY_ICO = gdi.Image(imgPath + "Buttons\\PLAY_ICO.png");
var PAUSE_ICO = gdi.Image(imgPath + "Buttons\\PAUSE_ICO.png");
var STOP_ICO = gdi.Image(imgPath + "Buttons\\STOP_ICO.png");

var NEXT_ICO_ = gdi.Image(imgPath + "Buttons\\NEXT_ICO_.png");
var PREV_ICO_ = gdi.Image(imgPath + "Buttons\\PREV_ICO_.png");
var PLAY_ICO_ = gdi.Image(imgPath + "Buttons\\PLAY_ICO_.png");
var PAUSE_ICO_ = gdi.Image(imgPath + "Buttons\\PAUSE_ICO_.png");
var STOP_ICO_ = gdi.Image(imgPath + "Buttons\\STOP_ICO_.png");
var STOP_ICO_2 = gdi.Image(imgPath + "Buttons\\STOP_ICO_2.png");

var MUTE0_ICO = gdi.Image(imgPath + "Buttons\\MUTE_ICO.png");
var MUTE1_ICO = gdi.Image(imgPath + "Buttons\\MUTE1_ICO.png");
var MUTE2_ICO = gdi.Image(imgPath + "Buttons\\MUTE2_ICO.png");
var MUTE3_ICO = gdi.Image(imgPath + "Buttons\\MUTE3_ICO.png");

var SHUFFLE_ICO = gdi.Image(imgPath + "Buttons\\SHUFFLE_ICO.png");
var SHUFFLE_ICO_ = gdi.Image(imgPath + "Buttons\\SHUFFLE_ICO_.png");
var SHUFFLE_ICO_2 = gdi.Image(imgPath + "Buttons\\SHUFFLE_ICO_2.png");

var REPEAT_ICO = gdi.Image(imgPath + "Buttons\\REPEAT_ICO.png");
var REPEAT_ICO_ = gdi.Image(imgPath + "Buttons\\REPEAT_ICO_.png");
var REPEAT_ICO_2 = gdi.Image(imgPath + "Buttons\\REPEAT_ICO_2.png");

var MUTE_ICO = gdi.Image(imgPath + "Buttons\\MUTE_ICO.png");
var MUTE_ICO_0 = gdi.Image(imgPath + "Buttons\\MUTE_ICO_0.png");
var MUTE_ICO_1 = gdi.Image(imgPath + "Buttons\\MUTE_ICO_1.png");
var MUTE_ICO_2 = gdi.Image(imgPath + "Buttons\\MUTE_ICO_2.png");
var MUTE_ICO_3 = gdi.Image(imgPath + "Buttons\\MUTE_ICO_3.png");

var MENU_ICO = gdi.Image(imgPath + "Buttons\\MENU_ICO.png");
var MENU_ICO_ = gdi.Image(imgPath + "Buttons\\MENU_ICO_.png");

var VOL_L = gdi.Image(imgPath + "Buttons\\VOL_L.png");
var VOL = gdi.Image(imgPath + "Buttons\\VOL.png");

var SEEK_L1 = gdi.Image(imgPath + "Buttons\\SEEK_L1.png");
var SEEK_L2 = gdi.Image(imgPath + "Buttons\\SEEK_L2.png");
var SEEK = gdi.Image(imgPath + "Buttons\\SEEK.png");

//var back = gdi.Image(imgPath + "Buttons\\BACK.png");

       
   var WshShell = new ActiveXObject("WScript.Shell");
   var CtrlDown = ShiftDown = button_timer = xy = false;
   var button_timeout;
   var hbtn;
   var dbtn; 
   var tooltip = window.CreateTooltip();
   tooltip.SetMaxWidth(200);

// ===================================================== // 


function Button(x, x2, y, w, h, img, img2, onclick, tiptext) {

    this.x = x;
    this.x2 = x2;
    this.y = y;
    this.w = w;
    this.h = h;
    this.img = img;
    this.img2 = img2;
    this.onclick = onclick;
    this.state = 0;
    this.opacity = 0;
    this.refresh = 0;
    this.tiptext = tiptext;
    
    this.xy = function (x, y) {

        return (this.x <= x) && (x <= this.x + this.w) && (this.y <= y) && (y <= this.y + this.h);

    }

// ===================================  
    
    this.changeState = function (state) {
    
        //if (!button_timer) button_timer = window.CreateTimerInterval(60);
		/*
		if (!button_timer) button_timer = window.SetInterval(function() {
			for (var i = 0; i < $buttons.length; i++) {
				if ($buttons[2].refresh) {
					$buttons[2].Opacity();
				}
			}
		}, 60);*/

        window.RepaintRect(this.x-2, this.y-2, this.w+4, this.h+4);
        
        this.state = state;
        this.refresh = 1;

        switch (state) {
        case 0:
        if(window.GetProperty("TipText")==true){
		tooltip.Text = "";
        tooltip.Deactivate();}
        window.SetCursor(32512);
        break;
        case 1:
        if(window.GetProperty("TipText")==true){
        tooltip.Text = this.tiptext;
        tooltip.Activate();}
        window.SetCursor(32649);
        break;
        case 2:
        }
    }
    
//------------------> Draw Buttons

  this.draw = function (gr) {
  
    var state = this.state;
    var op = this.opacity;
    on_draw(gr, x, x2, y, w, h, img, img2, op, state);

   }

// ===================================
    
    this.Opacity = function () {
             
        if(this.state == 1 && this.opacity < 255)
        this.opacity = Math.min(this.opacity + 10, 255);
        
        if(this.state == 0 && this.opacity > 0)
        this.opacity = Math.max(0,this.opacity - 10);
       
        if (this.opacity == 0){ 
			this.refresh = 0;
			//button_timeout = window.CreateTimerTimeout(3000);
			/*button_timeout = window.SetTimeout(function() {
				if (button_timer) window.ClearInterval(button_timer);//window.KillTimer(button_timer);
				button_timer = false;
			}, 3000);*/
        }             
     
        //window.RepaintRect(ww/2-H.width/2, wh-H.height+1, H.width, H.height);
 
    };

// ===================================
    
    this.onClick = function () {
        this.onclick && this.onclick();
    }
}

// ========================================================================== //
//var g_hover = false;
buttons_on_mouse_move = function(x, y){

    xy = false;

    for (var i = 0; i < $buttons.length; i++)

    if ($buttons[i].xy(x, y)) {

    xy = true;
	
    if (hbtn != $buttons[i]) {
    if (hbtn) hbtn.changeState(0);
        hbtn = $buttons[i];
        hbtn.changeState(1);
        };
    }

    if (xy == false) {
        if (hbtn) {
        hbtn.changeState(0);
        hbtn = undefined;
        };
		/*
		for (var i = 0; i < $buttons.length; i++) {
			if ($buttons[2].refresh) {
				$buttons[2].Opacity();
				window.RepaintRect(ww/2-H.width/2, wh-H.height+1, H.width, H.height);
			}
		}*/
		/*
		if (button_timeout) {
			if (button_timer) window.ClearInterval(button_timer);//window.KillTimer(button_timer);
			button_timer = false;
		}*/
    }
}

// ========================================================================== //

buttons_on_mouse_lbtn_down = function (x, y) {

    if (hbtn) {
        dbtn = hbtn;
        dbtn.changeState(2);

    }
}

// ========================================================================== //

buttons_on_mouse_lbtn_up = function (x, y) {

    if (dbtn) {
        dbtn.changeState(1);
        dbtn.onClick();
        dbtn = undefined;
    }

}

// ========================================================================== //
//var H_timeout;
//var H = B;
buttons_on_mouse_leave = function () {
    if (hbtn) {
        hbtn.changeState(0);
        hbtn = undefined;
    }
/*
	H_timeout = window.SetTimeout(function() {
	
		for (var i = 0; i < $buttons.length; i++) {
			if ($buttons[2].refresh) {
				$buttons[2].Opacity();
				window.RepaintRect(ww/2-H.width/2, wh-H.height+1, H.width, H.height);
			}
		}
		window.RepaintRect(ww/2-H.width/2, wh-H.height+1, H.width, H.height);
	}, 150);
*/
}
    
// ========================================================================== //
/*
buttons_on_timer = function(id){

    if (button_timeout && id == button_timeout.ID) {
        if (button_timer) window.ClearInterval(button_timer);//window.KillTimer(button_timer);
        button_timer = false;
    }

    for (var i = 0; i < $buttons.length; i++) {
        if ($buttons[2].refresh) {
            $buttons[2].Opacity();
        }
    }
}*/