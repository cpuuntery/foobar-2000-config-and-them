// Control Panel for StrigUI

// Loading additional files
include(fb.FoobarPath + 'themes\\strigUI\\scripts\\Flags.js');
include(fb.FoobarPath + 'themes\\strigUI\\scripts\\Buttons.js');

// panel height
var height = 60; //64

// Generate/modify colours
function RGBA(r, g, b, a) {
	return a << 24 | r << 16 | g << 8 | b;
}
function RGB(r, g, b) {
	return 0xFF000000 | r << 16 | g << 8 | b;
}

// Options engine {{
var cfgPath = fb.ProfilePath + "themes\\strigUI\\_cfg.ini";
function update_option(optname, optvalue) {
		var ini_ = utils.ReadINI(fb.ProfilePath + '_cfg.ini', 'SEEKopts', optname);
		if ( optname ) utils.WriteINI( fb.ProfilePath + '_cfg.ini', 'SEEKopts', optname, optvalue);
		else if ( !optname && ini_ ) optname = ini_;
		//else if ( !optname && !ini_) optname = optvalue;
		else optname = optvalue;
}
function read_option(optname, initvalue) {
		var ini_ = utils.ReadINI(fb.ProfilePath + '_cfg.ini', 'SEEKopts', optname);
		if (ini_ == "") ini_ = initvalue;
		return ini_
}

var seek_height;
var show_seekbar = window.GetProperty("switcher",0);
if (!show_seekbar) {
	window.SetProperty("switcher", show_seekbar);
	show_seekbar = window.GetProperty("switcher",0);
}


function update_MinMaxHeight() {
	//show_seekbar = read_option("show_seekbar", 1);
	if (show_seekbar == 1) {
		height = 54;
		update_option("show_seekbar", 1);
	} else {
		height = 67;
		update_option("show_seekbar", 0);
	}
	window.MinHeight = window.MaxHeight = height; 
}
update_MinMaxHeight();
 
var d = new Date();
//var g_textrender = gdi.CreateStyleTextRender();
var str = "";
var WshShell = new ActiveXObject("WScript.Shell");
 
// ---> Initial timers
window.SetInterval(function() {
    if (!fb.IsPlaying || fb.IsPaused || fb.PlaybackLength == 0) return;
    window.RepaintRect(seek_x - 10 + (seek_pos > 25 ? (seek_pos - 25) : 0), seek_y, 50, seek_h); // seek area
}, 150);
 
window.SetInterval(function(){ // create timer for initial clock display
    if (fb.IsPlaying) return;
    d = new Date();
    window.RepaintRect(time_x, time_y, time_w, time_h); // time area
}, 1000);
 
// ---> Additional images
var imgPath = fb.ProfilePath + "themes\\strigUI\\Images\\";
var SEEK_L1 = gdi.Image(imgPath + "Buttons\\SEEK_L1.png");
var SEEK_L2 = gdi.Image(imgPath + "Buttons\\SEEK_L2.png");
var dsp_button_img = gdi.Image(imgPath + "Buttons\\DSP_man.png");
var eq_button_img = gdi.Image(imgPath + "Buttons\\EQ_ICO.png");
var output_button_img = gdi.Image(imgPath + "Buttons\\OUT_ICO.png");
var adj_button_img = gdi.Image(imgPath + "Buttons\\DJ_ICO.png");
var adj_button_down_img = gdi.Image(imgPath + "Buttons\\DJ_H_ICO.png");
var queue_button_img = gdi.Image(imgPath + "Buttons\\QUEUE_ICO.png");
var queue_button_down_img = gdi.Image(imgPath + "Buttons\\QUEUE_ICO_.png");
var playlists_img = gdi.Image(imgPath + "Buttons\\PLAYLIST_ICO.png");
var TIME_BG = gdi.Image(imgPath + "Buttons\\TIME.png");
 
// ---> More vars
var XYinVol = XYinVol_h = vol_drag = volume_change = sac = saci = XYinSeek = XYinSeek_h = XYinMenu = lbtn_down = seek_drag = ShiftDown = vol_timer = false;
var vol_pos = volstate = vol_x = vol_y = vol_w = vol_h = time_x = time_y = time_w = time_h = time_pos = seek_pos = ww = wh = 0;
 
// ================================================== //
// --->    Draw a star function
function DrawPolyStar(gr, x, y, out_radius, in_radius, points, line_thickness, line_color, fill_color, angle, opacity) {
    //if(!opacity && opacity != 0) opacity = 255;
   
        //---> Create points
    var point_arr = [];
 
    for (var i = 0; i != points; i++) {
        i % 2 ? r = Math.round((out_radius-line_thickness*4)/2) / in_radius : r = Math.round((out_radius-line_thickness*4)/2);
        var x_point = Math.floor(r * Math.cos(Math.PI * i / points * 2 - Math.PI / 2));
        var y_point = Math.ceil(r * Math.sin(Math.PI * i / points * 2 - Math.PI / 2));
        point_arr.push(x_point + out_radius/2);
        point_arr.push(y_point + out_radius/2);
    }
       
    //---> Crate polygon image
    var img = gdi.CreateImage(out_radius, out_radius);
    var _gr = img.GetGraphics();
   
    _gr.SetSmoothingMode(2);
    _gr.FillPolygon(fill_color, 1, point_arr);
   
    if(line_thickness > 0) 
	_gr.DrawPolygon(line_color, line_thickness, point_arr);  
   
    img.ReleaseGraphics(_gr);
   
    //---> Draw image
    gr.DrawImage(img, x, y, out_radius, out_radius, 0, 0, out_radius, out_radius, angle || 0, opacity || 255);
}
 
// --->    Volume funcs
function pos2vol(p) {
    return (50 * Math.log(0.99 * p + 0.01) / Math.log(10));
}
function vol2pos(v) {
    return (((Math.pow(10, v / 50) - 0.01) / 0.99));
}
 
// --->    Auto DJ functions    
function id_playlist(name){
    //fb.RunMainMenuCommand("Playback/Order/Default");
    var pl_dj;
    for (var i = 0; i <= plman.PlaylistCount; i++) {
        if (plman.GetPlaylistName(i) == name) {
            pl_dj = i;
            break;
        }
    }
    return pl_dj;
}
 
function run_dj() {
    fb.RunMainMenuCommand("Playback/Order/Default");
    var pl_dj = id_playlist("Auto DJ");
    if ( pl_dj == "?" || !pl_dj ) { // is there a list like this?
        pl_dj = plman.PlaylistCount + 1;
        plman.CreatePlaylist(pl_dj, "Auto DJ");
        pl_dj = id_playlist("Auto DJ"); // double checking list id
    }
 
    var items = plman.GetPlaylistItems(pl_dj);
   
    if (items.Count < 1) { // that playlist must be new, lets seed a track and start playback so foo_random_pools can start working
    //if ( plman.PlaylistItemCount(pl_dj) < 1 ) {
        var selection = fb.GetSelections(0);
        var pos = 0;
        plman.SetPlaylistFocusItem(pl_dj, pos);
        plman.InsertPlaylistItems(pl_dj, pos, selection);
        plman.ExecutePlaylistDefaultAction(pl_dj, items.Count);
    }
       
    plman.ActivePlaylist = pl_dj;
    //var items = plman.GetPlaylistItems(plman.ActivePlaylist);
    plman.ExecutePlaylistDefaultAction(plman.ActivePlaylist, items.Count - 2);
       
    //if ( items.Count > 10 ) {
    if ( items.Count > 3 && !CtrlDown ) { // clear the old playlist and start a new one (if CTRL is not down)
        plman.ClearPlaylistSelection(plman.ActivePlaylist);
        plman.SetPlaylistSelectionSingle(plman.ActivePlaylist, items.Count - 2 , true); // fb.TitleFormat("%title%")
        plman.SetActivePlaylistContext();
        fb.RunMainMenuCommand("Edit/Selection/Crop");
    }
}
 
// --->    Queue track functions
function queue_track_last() {
    var selection = fb.GetSelections(0);
    var nowplaying = plman.GetPlayingItemLocation();
    var pid;
    if (fb.IsPlaying) {
        pid = nowplaying.PlaylistItemIndex;
        if(pid>=0 && pid<plman.PlaylistItemCount(plman.PlayingPlaylist)) {
            //plman.SetPlaylistFocusItem(plman.PlayingPlaylist, pid);
            CtrlDown ? plman.InsertPlaylistItems(plman.PlayingPlaylist, plman.PlaylistItemCount(plman.PlayingPlaylist) + 1, selection) : plman.InsertPlaylistItems(plman.PlayingPlaylist, pid + 1, selection);
        }
    } else {
        pid = plman.GetPlaylistFocusItemIndex(plman.PlayingPlaylist)
        plman.ExecutePlaylistDefaultAction(plman.PlayingPlaylist, pid);
    }
}
/*
// --->    CPU profiling
var UIHacks;
    uiHacks = utils.CheckComponent("foo_ui_hacks");
    if (uiHacks) {
        UIHacks = new ActiveXObject("UIHacks");
    }
var g_foo_cpu_usage = "";
UIHacks.CPUUsage;
window.SetInterval(function () {
    if(utils.IsKeyPressed(VK_ALT)) {
        g_foo_cpu_usage = UIHacks.FoobarCPUUsage.toFixed(1)+'%';
        window.RepaintRect(10, 70, 50, 12);
    } else {
        g_foo_cpu_usage = "";
    }
}, 1000);
*/
// ================================================== //
function on_draw(gr, x, x2, y, w, h, img, img2, op, state) {
   gr.DrawImage(img, Math.ceil(x), Math.ceil(y), Math.ceil(w), Math.ceil(h), 0, state*h, Math.ceil(w), Math.ceil(h), 0, 200); // creating background for buttons
   gr.DrawImage(img2, Math.ceil(x2), Math.ceil(y), Math.ceil(w), Math.ceil(h), 0, 0, Math.ceil(w), Math.ceil(h), 0, 200); // draw buttons
}
// ================================================== //
// ---> Callbacks
function on_paint (gr) {
	if (show_seekbar == 1) {
		gr.FillSolidRect(-1,0,ww+1,wh,RGB(60,60,60));
		gr.FillSolidRect(-1,0,ww+1,1,RGB(225,225,225));
		gr.FillSolidRect(-1,1,ww+1,1,RGB(55,55,55));
	} else {
		gr.FillSolidRect(-1,-1,ww+1,20,RGB(240,240,240));
		gr.FillSolidRect(-1,12,ww+1,wh-12,RGB(60,60,60));
		gr.FillSolidRect(-1,11,ww+1,1,RGB(225,225,225));
		gr.FillSolidRect(-1,12,ww+1,1,RGB(55,55,55));
	}
       
	// ---> FOO %cpu info
    //if(g_foo_cpu_usage.length > 0) gr.gdiDrawText(g_foo_cpu_usage, gdi.Font("arial", 9, 1), RGB(0,0,0), 10, 15, 30, 12, DT_LEFT | DT_TOP | DT_NOPREFIX | DT_END_ELLIPSIS);
   
	// --->    Draw Volume

    //if (fb.Volume > -1) var pos = vol_w-2;
    vol_pos = vol_w * vol2pos(fb.Volume);
    gr.DrawImage(VOL_L, vol_x+4, vol_y+7, vol_pos-4, VOL_L.Height+2, 0, 0, VOL_L.Width, VOL_L.Height, 0, 255);
    gr.DrawRoundRect(vol_x + 2, vol_y+5, vol_w, 8, 2, 2, 1, RGBA(255, 255, 255, 50));
    gr.DrawRoundRect(vol_x + 3, vol_y+6, vol_w - 2, 6, 2, 2, 1, RGBA(0, 0, 0, 150));
	gr.DrawImage(VOL, vol_x+vol_pos-4, vol_y+3, VOL.Width, VOL.Height/3, 0, (XYinVol && XYinVol_h) || vol_drag ? ( volstate ==2 || vol_drag ? 2*VOL.Height/3 : VOL.Height/3) : 0, VOL.Width, VOL.Height/3, 0, 255);


   
	// ---> Draw buttons
    for (var i = 0; i < $buttons.length; i++) {
        $buttons[i].draw(gr);
    }
   
    // --->    Draw Seek
    var s = seek_drag ? time_pos : fb.PlaybackTime;
    var hou = Math.floor((s % 86400) / 3600);
    var min = Math.floor(((s % 86400) % 3600) / 60) + ":";
    var sec = Math.floor(((s % 86400) % 3600) % 60);
    var hou = hou > 0 ? hou + ":" : "";
    var sec = sec < 10 ? "0" + sec : sec;
    var playback_time = hou + min + sec;
	
	// --- > show_seekbar
	
    if (seek_w > 10 && show_seekbar == 0) {
        gr.DrawRoundRect(seek_x, seek_y + 5, seek_w, 4, 2, 2, 1, RGBA(255, 255, 255, 50));
        gr.DrawRoundRect(seek_x + 1, seek_y + 6, seek_w - 2, 4, 1, 1, 1, RGBA(0, 0, 0, 90));
       
        if (fb.IsPlaying && fb.PlaybackLength > 0 && !seek_drag) {
            seek_pos = seek_w * (fb.PlaybackTime / fb.PlaybackLength) + 1;
        }
       
        if (fb.IsPlaying && fb.PlaybackLength > 0){
            if (seek_pos > 5) gr.DrawImage(SEEK_L1, seek_x + 2, seek_y + 6, seek_pos - 4, SEEK_L1.Height, 0, 0, SEEK_L1.Width, SEEK_L1.Height, 0, 255);
 
            if (!XYinSeek) {
                seek_pos < 18 ? se = 18 - seek_pos : se = 0;
                gr.DrawImage(SEEK_L2, seek_x + seek_pos - SEEK_L2.Width + se, seek_y + 6, SEEK_L2.Width, SEEK_L2.Height, se, 0, SEEK_L2.Width, SEEK_L2.Height, 0, 255);
            } else {
                gr.DrawImage(SEEK, seek_x + seek_pos - SEEK.Width / 2, seek_y + 4, SEEK.Width, SEEK.Height / 3, 0, XYinSeek_h || seek_drag ? (lbtn_down || seek_drag ? 2 * SEEK.Height / 3 : 1 * SEEK.Height / 3) : 0 * SEEK.Height / 3, SEEK.Width, SEEK.Height / 3, 0, 255);
            }
        }
    }

    // --->    Draw Text
	
	if (!volume_change) fb.IsPlaying ? str = playback_time + " " + fb.TitleFormat("'| '%length%").Eval(): str = d.toLocaleTimeString();
    if (seek_drag) var str = playback_time + "  (" + fb.TitleFormat("%playback_time_remaining%").Eval() + ")";
    if (volume_change) var str = Math.round(vol2pos(fb.Volume) * 100) + "% (" + Math.ceil(fb.Volume) + "db)";//Math.ceil(fb.Volume) + "db";

    gr.SetSmoothingMode(4);
	gr.DrawImage(TIME_BG, time_x, time_y, TIME_BG.Width, TIME_BG.Height, 0, 0, TIME_BG.Width, TIME_BG.Height, 0, 225);
	gr.GdiDrawText(str, gdi.Font("Trebuchet MS", 12, 1), RGB(230, 230, 230), time_x, time_y, time_w, time_h, DT_CENTER | DT_TOP | DT_NOPREFIX | DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE | DT_CALCRECT );
}
 
// ================================================== //
function CreateAutoPlaylist(playlistIndex, name, query, sort, flags) {
    if ("CreateAutoPlaylist" in fb)
        return fb.CreateAutoPlaylist(playlistIndex, name, query, sort, flags);
    else
        return plman.CreateAutoPlaylist(playlistIndex, name, query, sort, flags);
}

function IsAutoPlaylist(playlistIndex) {
    if ("IsAutoPlaylist" in fb)
        return fb.IsAutoPlaylist(playlistIndex);
    else
        return plman.IsAutoPlaylist(playlistIndex);
}

function ShowAutoPlaylistUI(playlistIndex) {
    if ("ShowAutoPlaylistUI" in fb)
        return fb.ShowAutoPlaylistUI(playlistIndex);
    else
        return plman.ShowAutoPlaylistUI(playlistIndex);
}

function on_size() {
    ww = window.Width;
    wh = window.Height;
    if (ww <= 0 || wh <= 0) return;
 
    seek_x = 10;
    seek_y = -2;
    seek_w = ww - seek_x*2;
    seek_h = 15;

    time_x = ww/2-330;
    time_y = wh-42;
    time_w = TIME_BG.Width; //109;
    time_h = TIME_BG.Height; //20;

    bx = ww/2-PLAY.Width/2 ;
    by = wh-PLAY.Height/3-3;
       
    vol_x = ww/2+190;
    vol_y = by+11;
    vol_w = 120;
    vol_h = 17;
	
	R_hoffset = 35;
	R_voffset = wh-PLAY.Height/3+6; 
	R_imgw = 22; 
    
	var MUTE = MUTE_ICO_3;
    if(fb.Volume < -10)  MUTE = MUTE_ICO_2;
    if(fb.Volume < -23)  MUTE = MUTE_ICO_1;
    if(fb.Volume < -80)  MUTE = MUTE_ICO_0;
    if(fb.Volume == -100)  MUTE = MUTE_ICO;
   
    if(plman.PlaybackOrder == 4) S_ICO = SHUFFLE_ICO_; // Shuffle tracks
    if(plman.PlaybackOrder == 5) S_ICO = SHUFFLE_ICO_2; // Shuffle albums
    if(plman.PlaybackOrder != 4 && plman.PlaybackOrder != 5) S_ICO = SHUFFLE_ICO;
   
    if(plman.PlaybackOrder == 2) R_ICO = REPEAT_ICO_; // Repaeat playlist
    if(plman.PlaybackOrder == 1) R_ICO = REPEAT_ICO_2; // Repeat track
    if(plman.PlaybackOrder != 1 && plman.PlaybackOrder != 2) R_ICO = REPEAT_ICO;
   
    var DJ_ICO;
    if(plman.GetPlaylistName(plman.PlayingPlaylist) != "Auto DJ") DJ_ICO = adj_button_img;
    if(plman.GetPlaylistName(plman.PlayingPlaylist) == "Auto DJ") DJ_ICO = adj_button_down_img;
   
    saci ? ST_ICO = STOP_ICO_2 : ST_ICO = STOP_ICO;
 
    $buttons = [
 
        new Button(bx-84, bx-84, by+8, B.Width, B.Height/3, B, fb.IsPlaying ? ST_ICO : STOP_ICO_, function () { // STOP
        CtrlDown == true ? fb.RunMainMenuCommand("Playback/Stop after current") : fb.Stop();
        },"Stop\n+Ctrl: Stop after current"),
        new Button(bx-PREV.Width, bx-PREV.Width+3, by+8, PREV.Width, PREV.Height/3, PREV, fb.IsPlaying ? PREV_ICO : PREV_ICO_, function () { // PREVIOUS
        fb.Prev();
        },""),
        new Button(bx, bx+1, by-1, PLAY.Width, PLAY.Height / 3, PLAY, fb.IsPlaying ? (fb.IsPaused ? PLAY_ICO : PAUSE_ICO) : PLAY_ICO_, function () { // PLAY
        fb.PlayOrPause();
        },""),
        new Button(bx+PLAY.Width, bx+PLAY.Width-5, by+8, NEXT.Width, NEXT.Height/3, NEXT, fb.IsPlaying ? NEXT_ICO : NEXT_ICO_, function () { // NEXT
        fb.Next();
        },""),
        new Button(bx-150, bx-150, by+8, B.Width, B.Height/3, B, S_ICO, function () { // SHUFFLE
        plman.PlaybackOrder != 4 && plman.PlaybackOrder != 5 ? (CtrlDown ? plman.PlaybackOrder = 5 : plman.PlaybackOrder = 4) : (CtrlDown && plman.PlaybackOrder == 4) ? plman.PlaybackOrder = 5 : plman.PlaybackOrder = 0;
        },"Shuffle tracks\n+Ctrl: Shuffle albums"),
        new Button(bx-117, bx-117, by+8, B.Width, B.Height/3, B, R_ICO, function () { // REPEAT
        plman.PlaybackOrder != 1 && plman.PlaybackOrder != 2 ? (CtrlDown ? plman.PlaybackOrder = 1 : plman.PlaybackOrder = 2) : (CtrlDown && plman.PlaybackOrder == 2) ? plman.PlaybackOrder = 1 : plman.PlaybackOrder = 0;
        },"Repeat track\n+Ctrl: Repeat playlist"),
        new Button(bx+175, bx+177, by+8, B.Width, B.Height/3, B, MUTE, function () { // MUTE VOLUME
        fb.VolumeMute();
        },"Mute"),
       
        new Button(bx+105, bx+105, by+8, B.Width, B.Height/3, B, fb.IsPlaying ? queue_button_img : queue_button_down_img, function () { // QUEUE track
            queue_track_last();
        },"Queue track\n+Ctrl: Queue to the end of playlist"),
       
        new Button(bx+140, bx+139, by+8, B.Width, B.Height/3, B, DJ_ICO, function () { // AUTODJ
            run_dj();
        },"Auto DJ\n+Ctrl: Enable without clearing playlist"),
       
        /*new Button(ww-135, ww-135, by+8, B.Width, B.Height/3, B, eq_button_img, function () {
        fb.RunMainMenuCommand("View/Equalizer");
        }),*/
        new Button(ww-75, ww-75, by+8, B.Width, B.Height/3, B, dsp_button_img, function () {
        CtrlDown == true ? fb.RunMainMenuCommand("View/DSP/Equalizer") : fb.RunMainMenuCommand("Playback/DSP settings/Preferences");
        },"DSP settings\n+Ctrl: Equalizer"),
       
        new Button(ww-105, ww-105, by+8, B.Width, B.Height/3, B, output_button_img, function () {
        fb.RunMainMenuCommand("Playback/Device/Preferences...");
        },"Configure audio output"),
       
		new Button(ww-135, ww-135, by+8, B.Width, B.Height/3, B, playlists_img, function () {
			if (CtrlDown == true) {
				plman.ActivePlaylist = plman.CreateAutoPlaylist(plman.PlaylistCount,"","");
				fb.RunMainMenuCommand("File/Rename Playlist") ;
				ShowAutoPlaylistUI(plman.ActivePlaylist);
			} else {
				plman.ActivePlaylist = plman.CreatePlaylist(plman.PlaylistCount,"");
				fb.RunMainMenuCommand("File/Rename Playlist") ;
			}
        },"New Playlists\n+Ctrl: New AutoPlaylist"),
	   
        new Button(ww-45, ww-45, by+8, ww > 482 ? B.Width : 0, ww > 482 ? B.Height/3 : 0, B, /*fb.IsPlaying ?*/ MENU_ICO /*: MENU_ICO_*/, function () {
           
			// ==================== Main Menu==================== //
			if (CtrlDown == true) {
				fb.RunMainMenuCommand("View/Layout/Enable layout editing mode");
				return;
			} 
			let basemenu = window.CreatePopupMenu();
			let contextman = fb.CreateContextMenuManager();
			contextman.InitNowPlaying();
			
			let child1 = window.CreatePopupMenu(); //File
			let child2 = window.CreatePopupMenu(); //Edit
			let child3 = window.CreatePopupMenu(); //View
			let child4 = window.CreatePopupMenu(); //Playback
			let child5 = window.CreatePopupMenu(); //Library
			let child6 = window.CreatePopupMenu(); //Help
			let child7 = window.CreatePopupMenu(); //Now playing
			
			let menuman1 = fb.CreateMainMenuManager();
			let menuman2 = fb.CreateMainMenuManager();
			let menuman3 = fb.CreateMainMenuManager();
			let menuman4 = fb.CreateMainMenuManager();
			let menuman5 = fb.CreateMainMenuManager();
			let menuman6 = fb.CreateMainMenuManager();
			
			// MF_STRING is defined in docs\\Flags.js
			child1.AppendTo(basemenu, MF_STRING, 'File');
			child2.AppendTo(basemenu, MF_STRING, 'Edit');
			child3.AppendTo(basemenu, MF_STRING, 'View');
			child4.AppendTo(basemenu, MF_STRING, 'Playback');
			child5.AppendTo(basemenu, MF_STRING, 'Library');
			child6.AppendTo(basemenu, MF_STRING, 'Help');
			basemenu.AppendMenuSeparator();
			child7.AppendTo(basemenu, MF_STRING, 'Now Playing');
			
			menuman1.Init('file');
			menuman2.Init('edit');
			menuman3.Init('View');
			menuman4.Init('playback');
			menuman5.Init('library');
			menuman6.Init('help');
			
			menuman1.BuildMenu(child1, 1, 200);
			menuman2.BuildMenu(child2, 201, 200);
			menuman3.BuildMenu(child3, 401, 200);
			menuman4.BuildMenu(child4, 601, 300);
			menuman5.BuildMenu(child5, 901, 300);
			menuman6.BuildMenu(child6, 1201, 100);
			
			contextman.InitNowPlaying();
			contextman.BuildMenu(child7, 1301);
			const ret = basemenu.TrackPopupMenu(ww-160, wh-200);
			//console.log('> '+ ret);
			if (ret >= 1 && ret < 201) {
				menuman1.ExecuteByID(ret - 1);
			}
			else if (ret >= 201 && ret < 401) {
				menuman2.ExecuteByID(ret - 201);
			}
			else if (ret >= 401 && ret < 601) {
				menuman3.ExecuteByID(ret - 401);
			}
			else if (ret >= 601 && ret < 901) {
				menuman4.ExecuteByID(ret - 601);
			}
			else if (ret >= 901 && ret < 1201) {
				menuman5.ExecuteByID(ret - 901);
			}
			else if (ret >= 1201 && ret < 1301) {
				menuman6.ExecuteByID(ret - 1201);
			}
			else if (ret >= 1301) {
				contextman.ExecuteByID(ret - 1301);
			}

        },"Main menu\n+Ctrl: Toggle layout edditing mode")
        ]
}
 
// ================================================== //
//var voltimeout;
function elements_on_mouse_move (x, y) {
    XYinVol = ((vol_x <= x) && (x <= vol_x + vol_w+5) && (vol_y <= y) && (y <= vol_y + vol_h));
    XYinSeek = ((seek_x <= x) && (x <= seek_x + seek_w) && (seek_y <= y) && (y <= seek_y + seek_h));
    XYinSeek_h = ((seek_x + seek_pos - SEEK.Width / 2 <= x) && (x <= seek_x + seek_pos - SEEK.Width / 2 + SEEK.Width) && (seek_y <= y) && (y <= seek_y + seek_h));

    var v = Math.max(0, Math.min(vol_w, x - vol_x)) / vol_w
    if (vol_drag == true && v >= 0) fb.Volume = pos2vol(v);
    if (vol_drag) window.RepaintRect(bx+185+B.Width, by+8, vol_w+10, vol_h); // vol area; VOL.Height
   
    if (fb.PlaybackTime > 0 && XYinSeek && seek_drag) {
        seek_pos = seek_w * (x / seek_w) - seek_x;
        time_pos = fb.PlaybackLength * (x - seek_x) / seek_w;
    }
    if (seek_drag) window.RepaintRect(seek_x - 15, 0, ww, wh); //Repaint seek area;*/
}
 
var rate_timer = rate_timeout = false;
 
function on_mouse_move(x, y) {
	elements_on_mouse_move (x, y);
    buttons_on_mouse_move(x, y);
   
    if (XYinVol || XYinSeek) {
        window.SetCursor(32649);
    } else {
        if (!hbtn) {
            window.SetCursor(32512);
        }
    }
}
 
// ================================================== //
function on_volume_change(val) {
    volume_change = true;
	vol_timer = setTimeout(function() { // using global timeout here to display volume value instead of time
		volume_change = false;
		window.RepaintRect(time_x, time_y, time_w, time_h); // time area
	}, 2000);
	
    window.RepaintRect(time_x, time_y, time_w, time_h); // time area
    window.RepaintRect(vol_x+vol_pos-VOL.Width/2-3, vol_y, VOL.Width+10, vol_h); // Repaint vol knob
    on_size();
    //window.RepaintRect(bx+100, by+5, 115, B.Height/3+5);
    window.RepaintRect(bx+185, by+8, B.Width+5, B.Height/3+5); // vol button area
	
}
 
// ================================================== //
 
function on_mouse_lbtn_down(x, y) {
    volstate == 1 ? volstate = 2: volstate = 0;
 
    if (XYinVol) {
        vol_drag = true;
        //on_mouse_move(x, y);
        elements_on_mouse_move (x, y);
    }
 //show_seekbar
    if (XYinSeek && fb.IsPlaying && show_seekbar == 0) {
        seek_drag = true;
        volume_change = false;
        if (fb.PlaybackTime > 0 && seek_drag) {
            //on_mouse_move(x, y);
            elements_on_mouse_move (x, y);
        }
    }
 // /show_seekbar
    CtrlDown = utils.IsKeyPressed(0x11) ? true : false;
    buttons_on_mouse_lbtn_down(x, y);
}
 
// ================================================== //
 
function on_mouse_lbtn_up(x, y) {
    volstate = 0;
    vol_drag = false;
   
    lbtn_down = false;
    if (XYinSeek && seek_drag) {
        //fb.PlaybackTime = fb.PlaybackLength * (x - seek_x) / seek_w;
		fb.PlaybackTime = Math.round(fb.PlaybackLength) * (x - seek_x) / seek_w;
    }
    seek_drag = false;
    window.Repaint();
   
    buttons_on_mouse_lbtn_up(x, y);
}
 
// ================================================== //
 
function on_mouse_leave() {
    XYinVol_h = XYinVol = XYinSeek = seek_drag = lbtn_down = vol_drag = XYinRate = false;
    //RATING
    //on_metadb_changed();

    if(!vol_timer) {
		volume_change = false;
		//buttons_on_mouse_leave();
	}
	
	buttons_on_mouse_leave();
}
 
function on_item_focus_change() {
	g_metadb = fb.IsPlaying ? fb.GetNowPlaying() : fb.GetFocusItem();
}
on_item_focus_change();
 
// ================================================== //

function on_playback_starting(cmd, is_paused) {
	on_size();
    window.Repaint(); 
}

// ================================================== //
 
function on_playback_pause(state) {
    on_size();
    window.RepaintRect(bx, by, PLAY.Width, PLAY.Height/3-3); // PLAY/PAUSE area
}
 
// ================================================== //
 
function on_playback_stop(reason) {
    if (reason != 2) {
        saci = false;
        seek_pos = 0;
        on_size();
        window.Repaint();
    }
}
 
// ================================================== //
 
function on_mouse_wheel(delta) {
    volume_change = true;
    fb.Volume = fb.Volume + delta * Math.exp(-fb.Volume / 33.333);
}
 
// ================================================== //
 
function on_mouse_lbtn_dblclk(x, y) {
    if(!xy && !XYinVol && !XYinRate && !XYinSeek)
    fb.ShowPreferences();
}
 
// ================================================== //
 
function on_mouse_rbtn_down(x, y) {
    ShiftDown = utils.IsKeyPressed(0x10) ? true : false;
}
 
// ================================================== //
 
function on_playlist_stop_after_current_changed(state) {
    state ? sac = true : sac = false;
    if(sac == false)  saci = false;
    on_size();
    //window.RepaintRect(ww/2-110,22,32,32); // stop area
	window.RepaintRect(ww/2-110, wh-PLAY.Height/3+3,32,32); // stop area
	console.log(wh-PLAY.Height/3+3);
}
   
// ================================================== //
   
function on_playback_time(time) {
    if (sac == true && Math.round(time % 2) == 1) {
        saci == false ? saci = true : saci = false;
        on_size();
        //window.RepaintRect(ww/2-110,12,32,32); // stop area
		window.RepaintRect(ww/2-110, wh-PLAY.Height/3+3,32,32); // stop area
    }
	if(volume_change == false) window.RepaintRect(time_x, time_y, time_w, time_h); // display volume value in time area
}
 
// ================================================== //
 
function on_playback_order_changed(new_order_index) {
    on_size();
    window.RepaintRect(bx-170, by+5, 70, B.Height/3+5); // PBO
}
// ================================================== //
 
function on_playback_new_track() {
    window.RepaintRect(0, 0, ww, 20); //Repaint seek area;
       
        //RATING
        if (rate_timer) { window.ClearInterval(rate_timer); rate_timer = false; }
        if (rate_timeout) { window.ClearInterval(rate_timeout); rate_timeout = false; }
        g_drag = 0;
    on_item_focus_change();
}  
// ================================================== //
 
function on_mouse_rbtn_up(x, y) {
 
var Menu = window.CreatePopupMenu();
    Menu.AppendMenuItem(MF_STRING, 1, "Google");
    Menu.AppendMenuItem(MF_STRING, 4, "Wikipedia");
    Menu.AppendMenuItem(MF_STRING, 5, "YouTube");
    //Menu.AppendMenuItem(MF_STRING, 6, "Last FM");
    Menu.AppendMenuItem(MF_STRING, 7, "Discogs");
	Menu.AppendMenuItem(MF_SEPARATOR, 0, 0);
	Menu.AppendMenuItem(MF_STRING, 10, "Waveform Seekbar");
	Menu.CheckMenuItem( 10, show_seekbar, bypos = false);
		
	if(ShiftDown){
		Menu.AppendMenuItem(MF_SEPARATOR, 0, 0);
		Menu.AppendMenuItem(MF_STRING, 18, "RuTracker");
		Menu.AppendMenuItem(MF_SEPARATOR, 0, 0);
		Menu.AppendMenuItem(MF_STRING, 19, "Reload");
		Menu.AppendMenuItem(MF_STRING, 20, "Properties");
		Menu.AppendMenuItem(MF_STRING, 21, "Configure...");
		//return false
	}
    Menu.AppendMenuItem(MF_SEPARATOR, 0, 0);
    Menu.AppendMenuItem(MF_STRING, 22, "Console");
    Menu.AppendMenuItem(MF_STRING, 23, "Restart Foobar");

    switch (Menu.TrackPopupMenu(x, y)) {
    case 1:
    try {WshShell.Run("http://images.google.com/search?q="+fb.TitleFormat("$replace(%artist%, ,+)&ie=utf-8").Eval(true));} catch (e) {};
    break;

    case 4:
    try {WshShell.Run("http://en.wikipedia.org/wiki/"+fb.TitleFormat("$replace(%artist%,' ','_','&','and')").Eval(true));} catch (e) {};
    break;  
    case 5:
    try {WshShell.Run("http://www.youtube.com/results?search_type=&search_query="+fb.TitleFormat("$replace(%artist%, ,+)&ie=utf-8").Eval(true));} catch (e) {};
    break;
    //case 6:
    //try {WshShell.Run("http://www.last.fm/music/" + fb.TitleFormat("$replace(%artist%,' ','+','&','and','/','%252F')").Eval(true));} catch (e) {};
    //break;
    case 7:
    try {WshShell.Run("http://www.discogs.com/search?q=" + fb.TitleFormat("$replace(%artist%+%album%, ,+)&ie=utf-8").Eval(true));} catch (e) {};
    break;
    case 18:
    try {WshShell.Run("http://rutracker.org/forum/tracker.php?nm=" + fb.TitleFormat("$replace(%artist%+%album%, ,+)&ie=utf-8").Eval(true));} catch (e) {};
    break;

 	case 10:
		if (show_seekbar == 0) {
			show_seekbar = 1;
		} else {
			show_seekbar = 0;	
		}
		window.SetProperty("switcher", show_seekbar);
		window.NotifyOthers("switcher", show_seekbar);	
		update_MinMaxHeight();
		window.Repaint();
    break; 
    case 19:
    window.Reload();
    break;
    case 20:
    window.ShowProperties();
    break;
    case 21:
    window.ShowConfigure();
    break;
    case 22:
    fb.ShowConsole();
    break;
    case 23:
    fb.RunMainMenuCommand("File/Restart");
    break;
    }
    return true
}

/*
function on_init() {
    var timer1 = window.SetTimeout(function(){
        window.NotifyOthers("switcher", g_switcher);
        timer1 && window.ClearTimeout(timer1);
    }, 50);
}
on_init();
var g_switcher = window.GetProperty("switcher",0);
window.SetProperty("switcher", g_switcher);
window.NotifyOthers("switcher", g_switcher);*/

/*
var g_switcher = window.GetProperty("switcher",0);
function update_MinMaxHeight() {
	if (g_switcher == 0) {
		height = 54;
	} else {
		height = 67;
	}
	window.MinHeight = window.MaxHeight = height; 
}
// toggler
if (g_switcher == 0) {
	g_switcher = 1;
} else {
	g_switcher = 0;	
}
window.SetProperty("switcher", g_switcher);
window.NotifyOthers("switcher", g_switcher);	
update_MinMaxHeight();
*/
/*
function on_notify_data(name, info) {
    switch(name) {
        case "switcher":
            switch(info) {
                case 0:
                    window.MaxHeight = 1;
                    //fb.trace("HIDE WAVEFORM")
                    break;
                case 1:
                    window.MaxHeight = 25;
                    //fb.trace("SHOW WAVEFORM")
                break;
            }
        break;
    }
}
*/