// Track Info Panel for StrigUI
// reworked version of Maxim Terpilovsky's script for displaying track/selection information

var string_height, string_number, min_width, column_number, max_elements, btns_ready, updated;
var Buttons = [];
var btn;
var hover_button = null;
var imgPath = fb.ProfilePath + "themes\\strigUI\\Images\\";

MF_STRING = 0x00000000;
DT_TOP = 0x00000000;
DT_LEFT = 0x00000000;
DT_RIGHT = 0x00000002;
DT_VCENTER = 0x00000004;
DT_CALCRECT = 0x00000400; 
DT_NOPREFIX = 0x00000800;
DT_END_ELLIPSIS = 0x00008000;

try { var folder = gdi.Image(imgPath + "big_folder.png"); }
catch(e) {var folder = false;  }

if ( utils.CheckFont( "Segoe UI" ) ) {
    var font            = gdi.Font("Segoe UI", 12, 0);
    var font_p1         = gdi.Font("Segoe UI", 13, 0);
    var font_p1_under   = gdi.Font("Segoe UI", 13, 4);
    var font_bold       = gdi.Font("Segoe UI", 12, 1);
    var font_under      = gdi.Font("Segoe UI", 12, 4);
} else {
    var font            = gdi.Font("Tahoma", 12, 0);
    var font_p1         = gdi.Font("Tahoma", 13, 0);
    var font_p1_under   = gdi.Font("Tahoma", 13, 4);
    var font_bold       = gdi.Font("Tahoma", 12, 1);
    var font_under      = gdi.Font("Tahoma", 12, 4);
}

fso = new ActiveXObject("Scripting.FileSystemObject");

mode                	= parseInt( utils.ReadINI(fb.ProfilePath + '_cfg.ini', 'info-panel-settings', 'track-info-mode', 1) );
rects               	= parseInt( utils.ReadINI(fb.ProfilePath + '_cfg.ini', 'info-panel-settings', 'rectangular-backs', 1) );
i_counter			= parseInt( utils.ReadINI(fb.ProfilePath + '_cfg.ini', 'info-panel-settings', 'item-counter', 1) );

function RGBA(r, g, b, a) {	return ((a << 24) | (r << 16) | (g << 8) | (b)); }
function RGB(r, g, b) { return (0xff000000 | (r << 16) | (g << 8) | (b)); }

function TimeFmt(t){
	var zpad = function(n){
		var str = n.toString();
		return (str.length<2) ? "0"+str : str;
	}
	var h = Math.floor(t/3600); t-=h*3600;
	var m = Math.floor(t/60); t-=m*60;
	var s = Math.floor(t);
	if(h>0) return h.toString()+":"+zpad(m)+":"+zpad(s);
	return m.toString()+":"+zpad(s);
}

function isArray(input){
    return typeof(input)=='object'&&(input instanceof Array);
}
/*
unique = function(arr) {
    var o = {}, i, l = arr.length, r = [];
    for(i=0; i<l;i+=1) o[arr[i]] = arr[i];
    for(i in o) r.push(o[i]);
    return r;
};
*/
max = function(arr) {
  return Math.max.apply(null, arr)
}

min = function(arr) {
  return Math.min.apply(null, arr)
}

indexOf = function(value, arr, start) {
    var i;
    if (!start) {
        start = 0;
    }
    for(i=start; i<arr.length; i++) {
        if(arr[i] == value) {
        return i;
        }
    }
    return -1;
}

function trim(string) {
    return string.replace(/(^\s+)|(\s+$)/g, "");
}

function calculate_dims() {

    string_height = 20;//font.Height + 5;
    string_number = Math.floor( window.Height / string_height );

    min_width = 200;
    column_number = 1//Math.floor( ( window.Width - window.Height - 6 ) / min_width );
    max_elements = column_number * string_number;
    //fb.trace('max_elements ' + max_elements);
}

function Button(x, y, w, h, label_size, update, name, hover, func) {
	this.name = name;
	this.func = func;
    this.hover = hover;
    this.update = update;

	this.traceMouse = function(x, y) {
        var b = (this.left <= x) && (x <= this.right) && (this.top <= y) && (y <= this.bottom);
        return b;

	};

    this.onHover = function( x, y) {
        this.hover && this.hover(  x, y, this.left, this.label_size );
    };
    

	this.onClick = function( x, y ) {
		this.func && this.func( x, y, this.left, this.label_size );
	};
}

function ClearButtonCoords() {
    for ( var n=Buttons.length; n--; ) {
        Buttons[n].x = 0;
        Buttons[n].y = 0;
        Buttons[n].w = 0;
        Buttons[n].h = 0;

        Buttons[n].left = 0;
        Buttons[n].top = 0;
        Buttons[n].right = 0;
        Buttons[n].bottom = 0;
        Buttons[n].label_size = 0;
    } 
}

function OnFilename() { window.SetCursor(32649); }
function Filename() {
    //try { fb.RunMainMenuCommand('View/Columns playlist/Activate now playing' ); }
    try { fb.RunContextCommand("Properties");}
    catch(e) { }
}


function OnTitle() { window.SetCursor(32649); }
function Title() {
    //try {  fb.RunContextCommandWithMetadb('Tagging/Discogs/Write Tags...', ItemInfo.CachedMetadb ); }
    /*try { fb.RunMainMenuCommand('View/Columns playlist/Activate now playing' ); }
    catch(e) { }*/
    var nowplaying = plman.GetPlayingItemLocation();
    var pid = nowplaying.PlaylistItemIndex;
    if(fb.IsPlaying && pid>=0 && pid<plman.PlaylistItemCount(plman.PlayingPlaylist)) {
        plman.ActivePlaylist = plman.PlayingPlaylist
        plman.SetPlaylistFocusItem(plman.PlayingPlaylist, pid);
        plman.SetPlaylistSelectionSingle(plman.PlayingPlaylist, pid, true)
    };
}

function OnArtist() { window.SetCursor(32649); }
function Artist() {
    try { fb.RunContextCommandWithMetadb('Quicksearch for same/Artist', ItemInfo.OutputMetadb(true) ); }
    catch(e) { }
}

function OnAlbum() { window.SetCursor(32649); }
function Album() {
    try { fb.RunContextCommandWithMetadb('Quicksearch for same/Album', ItemInfo.OutputMetadb(true) ); }
    catch(e) { }
}

function OnPath() { window.SetCursor(32649); }
function Path() {
    try { fb.RunContextCommandWithMetadb('Open containing folder', ItemInfo.OutputMetadb(true) ); }
    catch(e) { }
}

buttons = {
	filename:       new Button(0,0,0,0,0,0, "Filename", OnFilename, Filename ),
	codec:          new Button(0,0,0,0,0,0, "Codec", false, false ),
	artist:         new Button(0,0,0,0,0,0, "Artist", OnArtist, Artist ),
	album:          new Button(0,0,0,0,0,0, "Album", OnAlbum, Album ),
	title:          new Button(0,0,0,0,0,0, "Title", OnTitle, Title ),
	date:           new Button(0,0,0,0,0,0, "Date", false, false ),
    played:         new Button(0,0,0,0,0,0, "Played", false, false ),
    genre:          new Button(0,0,0,0,0,0, "Genre", false, false ),
    filesize:       new Button(0,0,0,0,0,0, "File size", false, false ),
    duration:       new Button(0,0,0,0,0,0, "Duration", false, false ),
    path:           new Button(0,0,0,0,0,0, "Path", OnPath, Path ),
    lastmodified:   new Button(0,0,0,0,0,0, "Last Modified", false, false )
}

for (var i in buttons ) {
	Buttons.push(buttons[i]);
}

function ClearButtonsVars() {
    //rating_view = 0;
    window.SetCursor(32512);
}

// fb.trace( dump(Buttons) );

function inArray(arr, val) {
    var i = arr.length;
    while (i--) {
        if (a[i] === val) return true;
    }
    return false;
}


function ItemInfo() {

    this.Selection = 0;
    this.ButtonsReady   = 0;
    this.Info   = false;
    this.Labels = false;
    this.CachedMetadb = undefined;
    this.Extension = '';

	this.Eval = function( meta, field ) {

        path = meta ? meta.Path : '';
		return path.indexOf('://') > 0 ?  fb.TitleFormat( field ).Eval( true ) : fb.TitleFormat( field ).EvalWithMetadb( meta );

	}

    this.OutputMetadb = function( force ) {
        force = force ? force : false;

        if ( force ) {
            if ( mode == 2 ) return fb.GetFocusItem(true);
            else return ( fb.IsPlaying ? fb.GetNowPlaying() : fb.GetFocusItem() );
        }
        else {
            if ( mode == 2 ) return (( fb.GetSelections().Count > 1 ) ? fb.GetSelections() : fb.GetFocusItem(true) );
            else return ( fb.IsPlaying ? ( ( fb.GetSelections().Count > 1 ) ? fb.GetSelections() : fb.GetNowPlaying() ) : ( fb.GetSelections().Count > 1 ? fb.GetSelections() : (fb.GetFocusItem(true) ? fb.GetFocusItem(true) : false) ));

        }
    }

	this.GetInfo = function( metadb ) {
        //console.log('GetInfo called');
		if ( metadb ) {

            labels = [];
            general = [];

            if ( metadb.Count != null && metadb.Count > 0 ) {

                //d = new Date();
                //t = d.getTime();

                // Constant values

                this.Extension  = [];
                var count = metadb.Count;

                /*if ( count > 1 ) {
                    var rating    = false;
                    var playcount = false;
                }
                else {
                    var rating    = 0;
                    var playcount = new Number();
                }*/

                var duration = 0;
                var filesize = 0;
                var bitrate = 0;

                var date_max    = 0;
                var date_min    = 10000;
                var filename    = '';
                var path        = false;

                var artist  = [];
                var album   = [];
                var codec   = [];
                var genre   = [];
                var extensions   = [];

                //this.Extension  = new Array('fpl', 'fpl');
                var title        = count + ' titles';
/*
                function iterate( item ) {

                    var info = item.GetFileInfo();

                    var artist_current = info.MetaValue( info.MetaFind('artist'), 0);
                    if ( artist_current ) artist.push( artist_current );

                    var album_current = info.MetaValue( info.MetaFind('album'), 0);
                    if ( album_current ) album.push( album_current );

                    var bit_cur  = info.InfoValue( info.InfoFind('bitrate' ) );
                    bitrate     += bit_cur ? parseInt( bit_cur ) : 0;

                    var dur_cur  = item.Length;
                    duration    += parseInt( dur_cur );
                    filesize    += bit_cur / 8 * 1024 * dur_cur;

                    extensions.push( item.RawPath.replace(/.*\.(\w+)$/,"$1") );
                }

                function duff(iterations) {
                    var i = iterations % 8;
                    var n = 0;
                    if( i>0 ) {
                        do {
                           var item = metadb.Item( n++ );
                           iterate(item);
                        }
                        while(--i);
                      }
                      i = parseInt( iterations / 8 );
                      if( i>0 ) {
                        do {
                           var item = metadb.Item( n++ );
                           iterate(item);

                           var item = metadb.Item( n++ );
                           iterate(item);

                           var item = metadb.Item( n++ );
                           iterate(item);

                           var item = metadb.Item( n++ );
                           iterate(item);

                           var item = metadb.Item( n++ );
                           iterate(item);

                           var item = metadb.Item( n++ );
                           iterate(item);

                           var item = metadb.Item( n++ );
                           iterate(item);

                           var item = metadb.Item( n++ );
                           iterate(item);
                        }
                        while(--i);
                    }
                }
*/
				if ( i_counter ) { // disable counter on demand 
					//duff( metadb.Count );
					duration = metadb.CalcTotalDuration()
                    filesize = metadb.CalcTotalSize()

					if ( duration > 86400 ) {
                        x = duration;
                        seconds = parseInt( x % 60 );
                        x /= 60;
                        minutes = parseInt( x % 60 );
                        x /= 60;
                        hours = parseInt( x % 24 );
                        x /= 24;
                        days = parseInt( x );
                        /*
                        seconds += seconds > 1 ? ' seconds ' : ' second ';
                        minutes += minutes > 1 ? ' minutes ' : ' minute ';
                        hours   += hours   > 1 ? ' hours '   : ' hour ';
                        days    += days    > 1 ? ' days '    : ' day ';*/
                        seconds += ' s ';
                        minutes += ' m ';
                        hours   += ' h ';
                        days    += ' d ';
                        duration = days + hours + minutes + seconds;
                    }
                    else {
                        duration = TimeFmt(duration);
                    }

                    if ( filesize >= 1073741824 ) filesize = Math.round(filesize / 1073741824 * 100)/100 + "GB";
                    else if ( filesize >= 1048576 ) filesize = Math.round(filesize / 1048576 * 100)/100 + "MB";
                    else if ( filesize >= 1024 ) filesize = Math.round(filesize / 1024 * 100)/100 + "KB";
                    else filesize += 'B';
				}
				// ==============================================
/*
                    artist = unique(artist);
                    if ( artist.length > 2 ) artist = artist.length + ' artists';
                    else {artist = artist.join(", ");}
                    album = unique(album);
                    if ( album.length > 2 ) album = album.length + ' albums';
                    else {album = album.join(", ");}
*/
					artist = artist.join(", ");
					album = album.join(", ");
                    filename = 'Selection (' + metadb.Count + ' items)';
                    //this.Extension = unique(extensions);
					this.Extension = extensions;

                if ( filename ) { general.push(filename); labels.push("Filename");}
                if ( codec )    { general.push(codec); labels.push("Codec");}
                if ( artist )   { general.push(artist); labels.push("Artist");}
                if ( album )    { general.push(album); labels.push("Album");}
                if ( date )     { general.push(date); labels.push("Date");}
                if ( filesize )         { general.push(filesize ); labels.push("File size");}
                if ( duration )         { general.push(duration); labels.push("Duration");}

                this.Info = general.join("|||");
                this.Labels = labels.join("\n");

                //fb.trace(rating);
                //d = new Date();
                //t2 = d.getTime();
                //fb.trace( (t2 - t) + ' ms');

            }
            else {
                //d = new Date();
                //t = d.getTime();
                //fb.trace('this.GetInfo else called');
                this.Extension  = '';

                this.Extension  = fb.TitleFormat("$ext(%filename_ext%)").EvalWithMetadb(metadb);
                var filename    = fb.TitleFormat("$if3(%url%,%filename_ext%,)").EvalWithMetadb(metadb);
                var artist      = this.Eval(metadb, '[%album artist%][ / %track artist%]');
                var codec       = fb.TitleFormat("[$codec()][', '%codec_profile%][', '$info(bitrate) kbps][', '%samplerate% Hz][ '('$info(tool2)')']").EvalWithMetadb(metadb);
                var album       = fb.TitleFormat("[%album%]").EvalWithMetadb(metadb);
                var title       = this.Eval(metadb, '$meta(title)');
                var date        = fb.TitleFormat(/*"[%date%]"*/"$meta(date,0)").EvalWithMetadb(metadb);
                var genre       = fb.TitleFormat("[%genre%]").EvalWithMetadb(metadb);
                var filesize        = fb.TitleFormat("$if($strcmp($info(cue_embedded),yes),$div($mul($div($info(bitrate),8),%length_seconds%),1024) MB / )[%filesize_natural%]").EvalWithMetadb(metadb);
                var duration        = fb.TitleFormat("[%length%]").EvalWithMetadb(metadb);
                var path            = fb.TitleFormat("$replace(%path%,%filename_ext%,)").EvalWithMetadb(metadb);
                var last_modified   = fb.TitleFormat("[%last_modified%]").EvalWithMetadb(metadb);

                if ( filename ) { general.push(filename); labels.push("Filename");}
                if ( codec )    { general.push(codec); labels.push("Codec");}
                if ( artist )   { general.push(artist); labels.push("Artist");}
                if ( title )    { general.push(title); labels.push("Title");}
                if ( album )    { general.push(album); labels.push("Album");}
                if ( genre )     { general.push(genre); labels.push("Genre");}
                //general.push(rating); labels.push("Rating");
                if ( date )     { general.push(date); labels.push("Date");}
                if ( duration )         { general.push(duration); labels.push("Duration");}
                if ( last_modified )    { general.push(last_modified); labels.push("Last Modified");}
                if ( filesize )         { general.push(filesize ); labels.push("File size");}
                if ( path )             { general.push(path); labels.push("Path");}
                this.Info = general.join("|||");
                this.Labels = labels.join("\n");
                //d = new Date();
                //t2 = d.getTime();
                //fb.trace( (t2 - t) + ' ms');
            }

            window.Repaint();

		}
		else { this.Info = false; this.Labels = false; window.Repaint(); }

    }

    this.Update = function( metadb ) {

        metadb = metadb ? metadb : this.OutputMetadb();

        if ( metadb ) {

            try {       var a = this.CachedMetadb.Path ? this.CachedMetadb.Path : ' '; }
            catch(e) {  var a = ' '; }

            try {       var b = metadb.Path ? metadb.Path : ' '; }
            catch(e) {  var b = ' '; }

            try {       if ( metadb.Count ) var c = true; }
            catch(e) {  var c = false; }

            //fb.trace( typeof a + typeof b + typeof c);
            //fb.trace(  a + '/' + b + '/' + c);

            if ( a.replace(/(.*)\\(.*)\.(.*)$/,'$1') != b.replace(/(.*)\\(.*)\.(.*)$/,'$1') && !c ) {
                utils.GetAlbumArtAsync(window.ID, metadb, 0, false);
                this.Cover      = false;
            }
            else if ( c ) this.Cover = false;

            this.CachedMetadb   = metadb;
            this.Info           = false;
            this.Labels         = false;

            this.SelectionString = fb.GetSelectionType() + ' ' + fb.GetSelections().Count;
            this.Selection       = fb.GetSelections().Count;

            //fb.trace('Update = ' + this.Selection);

            this.ButtonsReady   = 0;
            ClearButtonCoords();

            this.GetInfo( metadb );
        }
        else {
            this.Info           = false;
            this.Labels         = false;
            this.CachedMetadb   = false;
            window.Repaint();
        }
    }

    this.Update();
}


ItemInfo = new ItemInfo();


function on_paint(gr) {

    //var start = new Date().getMilliseconds();
    //fb.trace( 'on_paint()' );

    var ww = window.Width;
    var wh = window.Height;

	gr.SetTextRenderingHint(5);
	//gr.SetSmoothingMode(4);
    gr.SetInterpolationMode(7);
    gr.FillSolidRect(0,0, ww, wh,RGB(240,240,240));

    if ( ItemInfo.Info ) {

        var Infos = ItemInfo.Info.split("|||");
        var Labels = ItemInfo.Labels.split("\n");

        var c = 1;
        var s = 1; 
        var max_label = 0;
        var current_label = 0;
        var label_widths = [];

        //if ( valign == 1 ) string_height = wh / string_number;

        Labels.splice(max_elements,Labels.length-max_elements)
        column_number = Math.ceil( Labels.length / string_number );
        var column_width = ww - 70//( ww - wh ) / column_number;

        var a = 0, b = Labels.length;
        //for ( a = 0; a < Labels.length; a++ ) {
        while ( a<b ) {

            var t = a % string_number;

            if ( !t ) {
                label_widths.push( max_label + 2 );
                max_label = 0;
            }

            current_label = Math.round( gr.MeasureString(Labels[a] + ':', font, 0, 0, ww, 0).Width );
            max_label = current_label > max_label ? current_label : max_label;

            if ( a + 1 == Labels.length ) {
                label_widths.push( max_label + 2 );
                max_label = 0;
            }

            a++;
            //fb.trace( Labels[a] + ' / current_label = ' + current_label + ' / max_label = ' + max_label + ' / column_number = ' + column_number );
        }

        label_widths.splice(0, 1);

        c = 1;
        s = 1; 

        //label_widths.reverse();

        //var a = Labels.length;
        for ( a = 0; a < Labels.length; a++ ) {
        //while ( a-- ) {

            if ( s > string_number && (s % string_number == 1 ) ) { c++; s = 1; }

            // LABEL
            var current_label_width = (Labels[a] == 'Filename' || Labels[a] == 'Codec' ) ? 55 : label_widths[c-1];

            if ( ItemInfo.ButtonsReady == 0 ) {

                var n = Buttons.length;
                while ( n-- ) {

                    if (  Buttons[n].name == Labels[a] ) {
                        Buttons[n].x = 70/*(wh )*/ + ( (c - 1) * column_width);
                        Buttons[n].y = (wh+5 - string_number * string_height)/2 + (s - 1) * string_height;
                        Buttons[n].w = column_width;
                        Buttons[n].h = string_height;

                        Buttons[n].left = Buttons[n].x;
                        Buttons[n].top = Buttons[n].y;
                        Buttons[n].right = Buttons[n].x + column_width;
                        Buttons[n].bottom = Buttons[n].y + string_height;
                        Buttons[n].label_size = current_label_width;
                    } else continue;
                }                
            }
            //ww - current_label_width - ((Labels[a] == 'Filename' || Labels[a] == 'Codec') ? 11 : 15)
            // RECT
            if ( rects ) gr.FillRoundRect( /*89*/((Labels[a] == 'Filename' || Labels[a] == 'Codec') ? 57 : 5) + ( (c - 1) * column_width), ((Labels[a] == 'Filename' || Labels[a] == 'Codec' ) ? -5 : 5) + 1 + (wh+5 - string_number * string_height)/2 + (s - 1) * string_height, /*column_width - 2*/ column_width + ((Labels[a] == 'Filename' || Labels[a] == 'Codec') ? 11 : 63), string_height - 2, 4, 4, (s % 2 == 0) ? RGBA(225,225,225,100) : RGBA(200,200,200,100));

            // LABELS
            gr.GdiDrawText( (Labels[a] == 'Filename' || Labels[a] == 'Codec' ) ? '' : Labels[a] + ':', (Labels[a] == 'Artist' || Labels[a] == 'Title' || Labels[a] == 'Album') ? font_bold : font, RGB( 120,120,120), 10 + ( (c - 1) * column_width), ((Labels[a] == 'Filename' || Labels[a] == 'Codec' ) ? 0 : 5) + (wh+5 - string_number * string_height)/2 + (s - 1) * string_height, current_label_width, string_height, DT_RIGHT | DT_VCENTER | DT_CALCRECT);

            if ( btn != null ) {
                if ( btn.name == Labels[a] && btn.func ) var font_this = (Labels[a] == 'Filename') ? font_p1_under : font_under;
                else var font_this = (Labels[a] == 'Filename') ? font_p1 : font;
            }
            //else { var font_this = (Labels[a] == 'Filename') ? font_p1 : font; }
            else { var font_this = (Labels[a] == 'Filename') ? font_p1 : font; }

            var color = (Labels[a] == 'Codec') ? RGB( 120,120,120) : (Labels[a] == 'Filename') ? RGB( 0, 0, 0) : RGB( 60, 60, 60);
            gr.GdiDrawText( Infos[a], font_this, color, ww-241 + ( Labels[a] ? current_label_width : 0 ) + ((c - 1) * column_width), ((Labels[a] == 'Filename' || Labels[a] == 'Codec' ) ? -5 : 5) + (wh+5 - string_number * string_height)/2 + (s - 1) * string_height, /*( ww - wh  ) / column_number - ( Labels[a] ? current_label_width + 5 : 5 )*/ ww - current_label_width - 15/*((Labels[a] == 'Filename' || Labels[a] == 'Codec') ? 14 : 15)*/, string_height, DT_NOPREFIX | DT_LEFT | DT_VCENTER | DT_END_ELLIPSIS | DT_CALCRECT);

            s++;
            if ( a == max_elements - 1 ) break;

        }

        // BUTTONS FORMED
        ItemInfo.ButtonsReady = 1;

        if ( ItemInfo.Extension != undefined ) {

            if ( isArray( ItemInfo.Extension ) ) {
                try {
					var icon = gdi.Image(imgPath + "formats\\generic.png");
                    var ih = 48 //icon.Height > wh ? ( wh - 4 - ItemInfo.Extension.length/2 ) : icon.Height;
                    var iw = 48 //icon.Width / ( icon.Height / ( wh - 4 - ItemInfo.Extension.length/2 ) );
                    icon = icon.Resize(iw,ih);
                } catch(e) { var icon = false; }
                if ( icon ) gr.DrawImage(icon, 4, 4, iw, ih, 0, 0, iw, ih, 0, 155);
            }
            else { 

            var ext = ItemInfo.Extension;
                ext = ext.toLowerCase();
                try {
                    var icon = ( fso.FileExists(imgPath + "formats\\" + ext + ".png" ) ) ? gdi.Image(imgPath + "formats\\" + ext + ".png" ) : gdi.Image(imgPath + "formats\\generic.png" );
                    var ih = 48 //icon.Height > wh ? wh - 5 : icon.Height;
                    var iw = 48 //icon.Width / ( icon.Width / (wh - 5) );
                    var icon_r = icon.Resize(iw,ih);
                } catch(e) { var icon = false; }
                if ( icon ) gr.DrawImage(icon_r, 4, 4, iw, ih, 0, 0, iw, ih, 0, 155);
            }
        }
        else {
            if ( folder ) gr.DrawImage(folder, 4, 4, folder.Width / ( folder.Height / (wh - 6) ), wh - 6, 0, 0, folder.Width, folder.Height, 0, 255);
        }
    }
    else {

        if ( plman.PlaylistItemCount(plman.ActivePlaylist) == 0 ) {
    
            if ( folder ) gr.DrawImage(folder, ww/2-64, wh/2-50, folder.Width/2, folder.Height/2, 0, 0, folder.Width, folder.Height, 0, 155);
            gr.GdiDrawText( 'Empty playlist', font_p1, RGB( 130, 130, 130), ww/2-40, wh/2-64, ww - 10, 20, DT_LEFT | DT_TOP | DT_CALCRECT);

        }
    }
}

function trackbuttons(x,y){
    var i = Buttons.length;
	while ( i-- ) {

		if ( Buttons[i].traceMouse(x, y) ) {

            var temp = Buttons[i];
            break;
		}
        else {
            var temp = false;
        }

	}

    if ( temp && ( btn != temp || temp.update == 1 ) ) {

        ClearButtonsVars();

        btn     = temp;
        btn.onHover(x,y);

        window.Repaint();

    }
    else if (!temp) {

        btn = false;
        ClearButtonsVars();
        window.Repaint();

    }
    return btn;
}



function on_mouse_move(x, y) {

	g_move = 1;
	hover_button = trackbuttons(x, y);

}

function on_mouse_lbtn_down(x,y){

	g_button_down = null;
	if (hover_button) {
        
		hover_button.onClick(x, y);
	}
	window.Repaint();

}

function on_metadb_changed(metadb) {

    ItemInfo.Update();
}

function on_size() {
    ww = window.Width;
    wh = window.Height;
    
    calculate_dims();
}

function on_playback_new_track(metadb) {

    var selection_metadb = metadb;
    var selection_temp = selection_metadb.RawPath != undefined ? selection_metadb.RawPath + '' + selection_metadb.SubSong : 'undefinedundefined';
    var cached_temp = ItemInfo.CachedMetadb ? (ItemInfo.CachedMetadb.RawPath + '' + ItemInfo.CachedMetadb.SubSong) : 'undefinedundefined';

    if ( selection_temp != cached_temp ) ItemInfo.Update( metadb );

}

function on_playback_dynamic_info_track() {

    ItemInfo.Update();

}

function on_playback_stop( Reason ) {

    if ( Reason == 0 ) on_item_focus_change();

}

function on_item_focus_change() {
    //fb.trace( 'on_item_focus: seltype = ' + fb.GetSelectionType() + ' count = ' + fb.GetSelections().Count + ' ??? = ' + ((!fb.IsPlaying || mode == 2)) );
    if ( (!fb.IsPlaying || mode == 2) && fb.GetSelections().Count < 2  ) {
        //fb.trace( 'on_item_focus_change()' );
        ItemInfo.Update();
    }
}


function on_selection_changed(metadb) {

    var selection_metadb = ItemInfo.OutputMetadb();
    var selection_temp = selection_metadb ? selection_metadb.RawPath + '' + selection_metadb.SubSong : 'undefinedundefined';

    var cached_temp = ItemInfo.CachedMetadb ? (ItemInfo.CachedMetadb.RawPath + '' + ItemInfo.CachedMetadb.SubSong) : 'undefinedundefined';

    var selection_string_temp = fb.GetSelectionType() + ' ' + fb.GetSelections().Count;
    var sel = fb.GetSelectionType();

    if ( ( ( ( sel == 0 && fb.GetSelections().Count >= 2 ) || ( sel == 0 && ItemInfo.Selection > 1 ) ) || ( ( sel == 1 ) && fb.GetSelections().Count >= 1 ) ) && ( ItemInfo.SelectionString != selection_string_temp || selection_temp ^ cached_temp ) ) {
        ItemInfo.Update();
    }
}

//function on_playback_edited() { ItemInfo.Update(); }

function on_playlist_switch() {
    if ( !fb.IsPlaying || mode == 2 ) {
        ItemInfo.Update();
    }
}

function on_playlist_items_added(playlist) {
    if ( (!fb.IsPlaying || mode == 2) && ItemInfo.Selection != fb.GetSelections().Count ) {
        ItemInfo.Update();
    }
}

function on_playlist_items_removed(playlist, new_count) {
    if ( (!fb.IsPlaying || mode == 2) ||  ItemInfo.Selection != fb.GetSelections().Count ) {
        ItemInfo.Update();
    }
}

function on_mouse_leave() {
    g_hover = false;
    ClearButtonsVars();
    btn = null;
    window.SetCursor( 32512 );
    window.Repaint();
}

function on_mouse_rbtn_up(x,y) {
    ShiftDown = utils.IsKeyPressed(0x10) ? true : false;
    if (ShiftDown) {
        return false; // if shift button pressed, show default context menu.
    } else {
        
		var _menu = window.CreatePopupMenu();
		var _firstgroup = window.CreatePopupMenu();
		var _secondgroup = window.CreatePopupMenu();

		var i = 1;
		var ret;

		_secondgroup.AppendMenuItem(MF_STRING, i++, "Enable rectangular backgrounds");
		_secondgroup.CheckMenuItem( i-1, rects);
		
		_firstgroup.AppendMenuItem(MF_STRING, i++, "Playing item");
		_firstgroup.AppendMenuItem(MF_STRING, i++, "Current selection");
		//_firstgroup.EnableMenuItem( mode+1, 1 );
		//_firstgroup.AppendMenuItem(mode+1 ? MF_STRING : MF_DISABLED, 1); //??????
		_firstgroup.CheckMenuRadioItem( 2, i - 1, mode+1 );

		_secondgroup.AppendTo( _menu, MF_STRING, "Visual settings");
		_firstgroup.AppendTo(  _menu, MF_STRING, "Focus settings");
		
		_secondgroup.AppendMenuItem(MF_STRING, i++, "Enable selection counter");
		_secondgroup.CheckMenuItem( i-1, i_counter);
		
		ret = _menu.TrackPopupMenu(x, y);
		if (ret == 1 ) {
			//window.ShowConfigure();
			utils.WriteINI( fb.ProfilePath + '_cfg.ini', 'info-panel-settings', 'rectangular-backs', rects = rects == 1 ? 0 : 1);
			window.Repaint();
		}
		else if (ret >= 2 && ret <= 3) {
			utils.WriteINI( fb.ProfilePath + '_cfg.ini', 'info-panel-settings', 'track-info-mode', mode = ret - 1);
			ItemInfo.Update();
		}
		else if (ret == 4 ) {
			utils.WriteINI( fb.ProfilePath + '_cfg.ini', 'info-panel-settings', 'item-counter', i_counter = i_counter == 1 ? 0 : 1);
			ItemInfo.Update();
		}
		return true;
	}
}
