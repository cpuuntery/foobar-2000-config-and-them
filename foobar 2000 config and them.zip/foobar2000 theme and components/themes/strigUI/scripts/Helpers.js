// Generate/modify colours
function RGBA(r, g, b, a) {
	return ((a << 24) | (r << 16) | (g << 8) | (b));
}

function RGB(r, g, b) {
	return (0xff000000 | (r << 16) | (g << 8) | (b));
}

function getAlpha(color) {
	return ((color >> 24) & 0xff);
}

// Helper function for DrawString() and MeasureString()
// args: h_align, v_align, trimming, flags
function StringFormat() {
	var h_align = 0, v_align = 0, trimming = 0, flags = 0;
	switch (arguments.length)
	{
	// fall-thru
	case 4:
		flags = arguments[3];
	case 3:
		trimming = arguments[2];
	case 2:
		v_align = arguments[1];
	case 1:
		h_align = arguments[0];
		break;
	default:
		return 0;
	}
	return ((h_align << 28) | (v_align << 24) | (trimming << 20) | flags);
}

var FontStyle = {
        Regular: 0,
        Bold: 1,
        Italic: 2,
        BoldItalic: 3,
        Underline: 4,
        Strikeout: 8
};

// fonts and colors

// Used in window.GetColorCUI()
ColorTypeCUI = {
	text: 0,
	selection_text: 1,
	inactive_selection_text: 2,
	background: 3,
	selection_background: 4,
	inactive_selection_background: 5,
	active_item_frame: 6
};

// Used in window.GetFontCUI()
FontTypeCUI = {
	items: 0,
	labels: 1
};

// Used in window.GetColorDUI()
ColorTypeDUI = {
	text: 0,
	background: 1,
	highlight: 2,
	selection: 3
};

// Used in window.GetFontDUI()
FontTypeDUI = {
	defaults: 0,
	tabs: 1,
	lists: 2,
	playlists: 3,
	statusbar: 4,
	console: 5
};

var g_instancetype = window.InstanceType;
var g_font = null;
var ww = 0, wh = 0;
var g_textcolor = 0, g_textcolor_hl = 0;
var g_backcolor = 0;
//var g_hot = false;

function get_font() {
    if (g_instancetype == 0) { // CUI
        g_font = window.GetFontCUI(FontTypeCUI.items);
    } else if (g_instancetype == 1) { // DUI
        g_font = window.GetFontDUI(FontTypeDUI.defaults);
    } else {
        // None
    }
}
get_font();

function get_colors() {
    if (g_instancetype == 0) { // CUI
        g_textcolor = window.GetColorCUI(ColorTypeCUI.text);
        g_textcolor_hl = window.GetColorCUI(ColorTypeCUI.text);
        g_backcolor = window.GetColorCUI(ColorTypeCUI.background);
    } else if (g_instancetype == 1) { // DUI
        g_textcolor = window.GetColorDUI(ColorTypeDUI.text);
        g_textcolor_hl = window.GetColorDUI(ColorTypeDUI.highlight);
        g_backcolor = window.GetColorDUI(ColorTypeDUI.background);
    } else {
        // None
    }
}
get_colors();

// PBO
var PlaybackOrder = {
	Default: 0,
	RepeatPlaylist: 1,
	RepeatTrack: 2,
	Random: 3,
	ShuffleTracks: 4,
	ShuffleAlbums: 5,
	ShuffleFolders: 6
}

/*
// Convert Point size to Pixel size (Useful in gdi.Font() and such)
function Point2Pixel(pt, dpi) {
	return (pt * dpi / 72);
}

function getRed(color) {
	return ((color >> 16) & 0xff);
}

function getGreen(color) {
	return ((color >> 8) & 0xff);
}

function getBlue(color) {
	return (color & 0xff);
}

function setAlpha(color, a) {
	return ((color & 0x00ffffff) | (a << 24));
}

function setRed(color, r) {
	return ((color & 0xff00ffff) | (r << 16));
}

function setGreen(color, g) {
	return ((color & 0xffff00ff) | (g << 8));
}

function setBlue(color, b) {
	return ((color & 0xffffff00) | b);
}

// Based on human hearing curve
// 0 <= p <= 1
// return a value value: -100 <= vol <= 0
function pos2vol(pos) {
     return (50 * Math.log(0.99 * p + 0.01) / Math.LN10);
}

// Inverse function of pos2vol()
function vol2pos(v){
     return (Math.round(((Math.pow(10, v / 50) - 0.01) / 0.99)));
}

// pre-calculated colors 
Colors = {
	AliceBlue			: 0xFFF0F8FF,
	AntiqueWhite		 : 0xFFFAEBD7,
	Aqua				 : 0xFF00FFFF,
	Aquamarine		   : 0xFF7FFFD4,
	Azure				: 0xFFF0FFFF,
	Beige				: 0xFFF5F5DC,
	Bisque			   : 0xFFFFE4C4,
	Black				: 0xFF000000,
	BlanchedAlmond	   : 0xFFFFEBCD,
	Blue				 : 0xFF0000FF,
	BlueViolet		   : 0xFF8A2BE2,
	Brown				: 0xFFA52A2A,
	BurlyWood			: 0xFFDEB887,
	CadetBlue			: 0xFF5F9EA0,
	Chartreuse		   : 0xFF7FFF00,
	Chocolate			: 0xFFD2691E,
	Coral				: 0xFFFF7F50,
	CornflowerBlue	   : 0xFF6495ED,
	Cornsilk			 : 0xFFFFF8DC,
	Crimson			  : 0xFFDC143C,
	Cyan				 : 0xFF00FFFF,
	DarkBlue			 : 0xFF00008B,
	DarkCyan			 : 0xFF008B8B,
	DarkGoldenrod		: 0xFFB8860B,
	DarkGray			 : 0xFFA9A9A9,
	DarkGreen			: 0xFF006400,
	DarkKhaki			: 0xFFBDB76B,
	DarkMagenta		  : 0xFF8B008B,
	DarkOliveGreen	   : 0xFF556B2F,
	DarkOrange		   : 0xFFFF8C00,
	DarkOrchid		   : 0xFF9932CC,
	DarkRed			  : 0xFF8B0000,
	DarkSalmon		   : 0xFFE9967A,
	DarkSeaGreen		 : 0xFF8FBC8B,
	DarkSlateBlue		: 0xFF483D8B,
	DarkSlateGray		: 0xFF2F4F4F,
	DarkTurquoise		: 0xFF00CED1,
	DarkViolet		   : 0xFF9400D3,
	DeepPink			 : 0xFFFF1493,
	DeepSkyBlue		  : 0xFF00BFFF,
	DimGray			  : 0xFF696969,
	DodgerBlue		   : 0xFF1E90FF,
	Firebrick			: 0xFFB22222,
	FloralWhite		  : 0xFFFFFAF0,
	ForestGreen		  : 0xFF228B22,
	Fuchsia			  : 0xFFFF00FF,
	Gainsboro			: 0xFFDCDCDC,
	GhostWhite		   : 0xFFF8F8FF,
	Gold				 : 0xFFFFD700,
	Goldenrod			: 0xFFDAA520,
	Gray				 : 0xFF808080,
	Green				: 0xFF008000,
	GreenYellow		  : 0xFFADFF2F,
	Honeydew			 : 0xFFF0FFF0,
	HotPink			  : 0xFFFF69B4,
	IndianRed			: 0xFFCD5C5C,
	Indigo			   : 0xFF4B0082,
	Ivory				: 0xFFFFFFF0,
	Khaki				: 0xFFF0E68C,
	Lavender			 : 0xFFE6E6FA,
	LavenderBlush		: 0xFFFFF0F5,
	LawnGreen			: 0xFF7CFC00,
	LemonChiffon		 : 0xFFFFFACD,
	LightBlue			: 0xFFADD8E6,
	LightCoral		   : 0xFFF08080,
	LightCyan			: 0xFFE0FFFF,
	LightGoldenrodYellow : 0xFFFAFAD2,
	LightGray			: 0xFFD3D3D3,
	LightGreen		   : 0xFF90EE90,
	LightPink			: 0xFFFFB6C1,
	LightSalmon		  : 0xFFFFA07A,
	LightSeaGreen		: 0xFF20B2AA,
	LightSkyBlue		 : 0xFF87CEFA,
	LightSlateGray	   : 0xFF778899,
	LightSteelBlue	   : 0xFFB0C4DE,
	LightYellow		  : 0xFFFFFFE0,
	Lime				 : 0xFF00FF00,
	LimeGreen			: 0xFF32CD32,
	Linen				: 0xFFFAF0E6,
	Magenta			  : 0xFFFF00FF,
	Maroon			   : 0xFF800000,
	MediumAquamarine	 : 0xFF66CDAA,
	MediumBlue		   : 0xFF0000CD,
	MediumOrchid		 : 0xFFBA55D3,
	MediumPurple		 : 0xFF9370DB,
	MediumSeaGreen	   : 0xFF3CB371,
	MediumSlateBlue	  : 0xFF7B68EE,
	MediumSpringGreen	: 0xFF00FA9A,
	MediumTurquoise	  : 0xFF48D1CC,
	MediumVioletRed	  : 0xFFC71585,
	MidnightBlue		 : 0xFF191970,
	MintCream			: 0xFFF5FFFA,
	MistyRose			: 0xFFFFE4E1,
	Moccasin			 : 0xFFFFE4B5,
	NavajoWhite		  : 0xFFFFDEAD,
	Navy				 : 0xFF000080,
	OldLace			  : 0xFFFDF5E6,
	Olive				: 0xFF808000,
	OliveDrab			: 0xFF6B8E23,
	Orange			   : 0xFFFFA500,
	OrangeRed			: 0xFFFF4500,
	Orchid			   : 0xFFDA70D6,
	PaleGoldenrod		: 0xFFEEE8AA,
	PaleGreen			: 0xFF98FB98,
	PaleTurquoise		: 0xFFAFEEEE,
	PaleVioletRed		: 0xFFDB7093,
	PapayaWhip		   : 0xFFFFEFD5,
	PeachPuff			: 0xFFFFDAB9,
	Peru				 : 0xFFCD853F,
	Pink				 : 0xFFFFC0CB,
	Plum				 : 0xFFDDA0DD,
	PowderBlue		   : 0xFFB0E0E6,
	Purple			   : 0xFF800080,
	Red				  : 0xFFFF0000,
	RosyBrown			: 0xFFBC8F8F,
	RoyalBlue			: 0xFF4169E1,
	SaddleBrown		  : 0xFF8B4513,
	Salmon			   : 0xFFFA8072,
	SandyBrown		   : 0xFFF4A460,
	SeaGreen			 : 0xFF2E8B57,
	SeaShell			 : 0xFFFFF5EE,
	Sienna			   : 0xFFA0522D,
	Silver			   : 0xFFC0C0C0,
	SkyBlue			  : 0xFF87CEEB,
	SlateBlue			: 0xFF6A5ACD,
	SlateGray			: 0xFF708090,
	Snow				 : 0xFFFFFAFA,
	SpringGreen		  : 0xFF00FF7F,
	SteelBlue			: 0xFF4682B4,
	Tan				  : 0xFFD2B48C,
	Teal				 : 0xFF008080,
	Thistle			  : 0xFFD8BFD8,
	Tomato			   : 0xFFFF6347,
	Transparent		  : 0x00FFFFFF,
	Turquoise			: 0xFF40E0D0,
	Violet			   : 0xFFEE82EE,
	Wheat				: 0xFFF5DEB3,
	White				: 0xFFFFFFFF,
	WhiteSmoke		   : 0xFFF5F5F5,
	Yellow			   : 0xFFFFFF00,
	YellowGreen		  : 0xFF9ACD32
};

var artist = ["Artist","%artist%"]; 
var album = ["Album","%album%"];
var title = ["Title","%title%"];
var discnumber = ["Discnumber","%discnumber%"];
var tracknumber = ["Tracknumber","%tracknumber%"];
var date = ["Date","%date%"];
var genre = ["Genre","%genre%"];
var album_artist = ["Album Artist","%album artist%"];
var composer = ["Composer",""];
var performer = ["Performer",""];
var tracknumber = ["Tracknumber","%tracknumber%"];
var totaltracks = ["Total Tracks","%totaltracks%"];
var discnumber = ["Discnumber","%discnumber%"];
var totaldiscs = ["Total Discs","%totaldiscs%"];
var comment = ["Comment","%comment%"];
var first_played = ["First Played","%first_played%"];
var last_played = ["Last Played","%last_played%"];
var play_count = ["Play Pount","%play_count%"];
var played_per_day = ["Played Per Day","%played_per_day%"];
var added = ["Added","%added%"];
var rating = ["Rating","%rating%"];
var rating_stars = ["Rating","%rating_stars_fixed%"];
var bitrate = ["Bitrate","%bitrate%"]; 
var channels = ["Channels","%channels%"];
var filesize = ["Filesize","%filesize%"];
var filesize_natural = ["Filesize Natural","%filesize_natural%"];
var samplerate = ["Samplerate","%samplerate%"];
var codec = ["Codec","%codec%"];
var playback_time = ["Playback Time","%playback_time%"];
var playback_time_seconds = ["Playback Time Seconds","%playback_time_seconds% "];
var playback_time_remaining = ["Playback Time Remaining","%playback_time_remaining%"];
var length = ["Length","%length%"];
var length_ex = ["Length ex","%length_ex%"];
var album_gain = ["Album Gain","%replaygain_album_gain%"];
var track_gain = ["Track Gain","%replaygain_track_gain%"];
var filename = ["Filename","%filename%"];
var directoryname = ["Directoryname","%directoryname%"];

//var WshShell = new ActiveXObject("WScript.Shell");
//var hWnd = utils.GetHWND("{97E27FAA-C0B3-4b8e-A693-ED7881E99FC1}");

Array.prototype.clean = function(deleteValue) {
  for (var i = 0; i < this.length; i++) {
    if (this[i] == deleteValue) {         
      this.splice(i, 1);
    }
  }
  return this;
};

Array.prototype.sum = function(){
	for(var i=0,sum=0;i<this.length;sum+=this[i++]);
	return sum;
}
*/