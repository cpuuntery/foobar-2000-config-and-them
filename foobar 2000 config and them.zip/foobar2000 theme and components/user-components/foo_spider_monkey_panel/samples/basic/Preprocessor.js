window.DefinePanel("Preprocessor", { author: "T.P Wang" });
include(`${fb.ComponentPath}samples\\basic\\js\\includeme.js`);

//check samples\basic\js\includeme.js for print_to_console function
print_to_console('Hello world!');

fb.ShowConsole();
