function print_to_console(msg) {
	console.log(msg);
}
